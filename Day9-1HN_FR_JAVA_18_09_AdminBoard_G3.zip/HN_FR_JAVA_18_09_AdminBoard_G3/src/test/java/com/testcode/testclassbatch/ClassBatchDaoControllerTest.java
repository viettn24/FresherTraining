package com.testcode.testclassbatch;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import fa.appcode.entity.ClassBatch;
import fa.appcode.service.ClassBatchServiceImpl;
import fa.appcode.web.controller.HomeController;

@ContextConfiguration(locations = {"classpath:dispatcher-test-servlet.xml"} )
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class ClassBatchDaoControllerTest {

  
  private MockMvc mockMvc;
  
  @Mock
  private ClassBatchServiceImpl classBatchServiceImpl;
  
  
  @Test
  public void testClassBatchController() {
    List<ClassBatch> listClassBatch = new ArrayList<>();
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    
    Mockito.when(classBatchServiceImpl.getAllClassBatch()).thenReturn(listClassBatch);
    
    mockMvc.perform(get("fds", 1L));
  }
  
  
  
  
  
  
  
  
  
}
