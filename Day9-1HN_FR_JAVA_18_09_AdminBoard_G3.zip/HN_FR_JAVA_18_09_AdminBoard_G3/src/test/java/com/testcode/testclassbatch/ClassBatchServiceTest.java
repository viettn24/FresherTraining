/*
*@author TienNV29
*@date Jan 28, 2019
*@version 1.0
*/

package com.testcode.testclassbatch;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fa.appcode.dao.ClassBatchDaoImpl;
import fa.appcode.entity.ClassBatch;
import fa.appcode.service.ClassBatchServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class ClassBatchServiceTest {
  
  @InjectMocks
  private ClassBatchServiceImpl classBatchServiceImpl;
  
  @Mock
  private ClassBatchDaoImpl classBatchDaoImpl;
  
  @Before
  public void setup() {
    
  }
  
  @Test
  public void testListClassBatchSuccess() {
    List<ClassBatch> listClassBatch = new ArrayList<>();
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    listClassBatch.add(new ClassBatch());
    
    Mockito.when(classBatchDaoImpl.getAllClassBatch()).thenReturn(listClassBatch);
    
    assertEquals(classBatchServiceImpl.getAllClassBatch().size(), 6);
  }
  
  
}
