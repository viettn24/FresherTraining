package com.testcode.testclassbatch;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import fa.appcode.dao.ClassBatchDao;
import fa.appcode.entity.ClassBatch;

@ContextConfiguration(locations = {"classpath:dispatcher-test-servlet.xml"} )
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class ClassBatchDaoTest {
  
  @Autowired
  private ClassBatchDao classBatchDao;
  
  @Test
  @Transactional
  public void TestClassBatch() {
    List<ClassBatch> listClassBatch = classBatchDao.getAllClassBatch();
    
    assertEquals(listClassBatch.size(), 6);
  }

}
