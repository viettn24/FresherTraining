package com.testcode.testTraineeTienNV29;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fa.appcode.dao.TraineeDaoImpl;
import fa.appcode.entity.AllowanceGroup;
import fa.appcode.entity.Faculty;
import fa.appcode.entity.Trainee;
import fa.appcode.entity.University;
import fa.appcode.service.TraineeServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class TTraineeServiceTest {
  
  @InjectMocks
  private TraineeServiceImpl traineeServiceImpl;
  
  @Mock
  private TraineeDaoImpl traineeDaoImpl;


  @Test
  public void listAllowanceGroup() {
    List<AllowanceGroup> listAllowanceGroup = new ArrayList<>();
    listAllowanceGroup.add(new AllowanceGroup());
    listAllowanceGroup.add(new AllowanceGroup());
    listAllowanceGroup.add(new AllowanceGroup());
    
    Mockito.when(traineeDaoImpl.getListAllowanceGroup()).thenReturn(listAllowanceGroup);
    
    assertEquals(traineeServiceImpl.getListAllowanceGroup().size(), 3);
    
  }
  
  @Test
  public void listFaculty() {
    List<Faculty> listFaculty = new ArrayList<>();
    listFaculty.add(new Faculty());
    listFaculty.add(new Faculty());
    listFaculty.add(new Faculty());
    
    Mockito.when(traineeDaoImpl.getListFaculty()).thenReturn(listFaculty);
    
    assertEquals(traineeServiceImpl.getListFaculty().size(), 3);
    
  }
  
  @Test
  public void listUniversity() {
    List<University> listUniversity = new ArrayList<>();
    listUniversity.add(new University());
    listUniversity.add(new University());
    listUniversity.add(new University());
    
    Mockito.when(traineeDaoImpl.getListUniversity()).thenReturn(listUniversity);
    
    assertEquals(traineeServiceImpl.getListUniversity().size(), 3);
    
  }
  


}
