package com.testcode.testTraineeTienNV29;

import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fa.appcode.dao.TraineeDaoImpl;
import fa.appcode.entity.Trainee;
import fa.appcode.service.TraineeServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class TTraineeServiceTestUpdateTraineeProfileTrue {

  private TraineeServiceImpl traineeServiceImpl = new TraineeServiceImpl();

  @Mock
  private TraineeDaoImpl traineeDaoImpl;

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Test(expected = Exception.class)
  public void test() throws Exception {
    Trainee theTrainee = new Trainee(2);

    Mockito.when(traineeDaoImpl.updateTraineeProfile(theTrainee))
        .thenReturn(true);
    assertTrue(traineeServiceImpl.updateTraineeProfile(theTrainee));

  }

}
