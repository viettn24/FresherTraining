package com.testcode.testTraineeTienNV29;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import fa.appcode.dao.ClassBatchDao;
import fa.appcode.dao.TraineeDao;
import fa.appcode.entity.AllowanceGroup;
import fa.appcode.entity.ClassBatch;
import fa.appcode.entity.Faculty;
import fa.appcode.entity.Trainee;
import fa.appcode.entity.TraineeProfile;
import fa.appcode.entity.University;

@ContextConfiguration(locations = {"classpath:dispatcher-test-servlet.xml"} )
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class TTraineeDaoTest {
  
  @Autowired
  private TraineeDao traineeDao;
  
  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }
  
  @Test
  @Transactional
  public void TestUpdateTraineeProfileFail() throws Exception{
    Trainee tempTrainee = traineeDao.getTrainee(1);
    
    TraineeProfile tempTraineeProfile = tempTrainee.getTraineeProfiles();
    
    tempTraineeProfile.setTraineeProfileId(100);
    
    tempTrainee.setTraineeProfiles(tempTraineeProfile);
    
    boolean updateResult = false;
      updateResult = traineeDao.updateTraineeProfile(tempTrainee);

    assertEquals(updateResult, false);;
    
  }
  
  @Test
  @Transactional
  public void TestUpdateTraineeProfileSuccess() throws Exception{
    Trainee tempTrainee = traineeDao.getTrainee(1);
    
    TraineeProfile tempTraineeProfile = tempTrainee.getTraineeProfiles();
    
    tempTraineeProfile.setEmail("emailIsChanged@gmail.com");
    
    tempTrainee.setTraineeProfiles(tempTraineeProfile);
    
    boolean updateResult = false;
      updateResult = traineeDao.updateTraineeProfile(tempTrainee);

    assertEquals(updateResult, true);;
    
  }
  
  @Test
  @Transactional
  public void TestFaculty() throws Exception{
    List<Faculty> listFaculty = traineeDao.getListFaculty();
    assertEquals(listFaculty.size(), 6);;
  }
  
  @Test
  @Transactional
  public void TestUniversity() throws Exception{
    List<University> listUniversity = traineeDao.getListUniversity();
    assertEquals(listUniversity.size(), 6);;
  }
  
  @Test
  @Transactional
  public void TestAllowanceGroup() throws Exception{
    List<AllowanceGroup> listAllowanceGroup = traineeDao.getListAllowanceGroup();
    assertEquals(listAllowanceGroup.size(), 6);;
  }
  
  
  
  
  
  
  

}
