package com.testcode.testuser;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fa.appcode.dao.UserDaoImpl;
import fa.appcode.entity.Users;
import fa.appcode.service.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
  
  @Mock
  private UserDaoImpl userDaoImpl;
  
  @InjectMocks
  private UserServiceImpl userServiceImpl;

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Test
  public void test() {
    Users theUsers = new Users(1, "alo", "123456", "enabled", null, null);
    Mockito.when(userDaoImpl.loadByUserName("alo")).thenReturn(theUsers);
    
    assertEquals(userServiceImpl.getUser(theUsers.getUsername()), theUsers);
    
  }

}
