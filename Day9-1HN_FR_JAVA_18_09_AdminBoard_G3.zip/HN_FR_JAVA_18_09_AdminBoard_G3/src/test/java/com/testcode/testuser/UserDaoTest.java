package com.testcode.testuser;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import fa.appcode.dao.ClassBatchDao;
import fa.appcode.dao.UserDao;
import fa.appcode.entity.ClassBatch;
import fa.appcode.entity.Users;

@ContextConfiguration(locations = {"classpath:dispatcher-test-servlet.xml"} )
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class UserDaoTest {
  
  @Autowired
  private UserDao userDao;
  
  @Test
  @Transactional
  public void TestUserDao() {
    Users tempUsers = userDao.loadByUserName("alo");
    
    assertEquals(tempUsers.getPassword(), "$2a$04$GYGsaJj9l6kH2GikK6QVzO0v3sOCxt3vdkiA2/tcoSw8erI85ZYDG");
  }

}
