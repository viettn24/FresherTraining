/*
*@author TienNV29
*@date Jan 25, 2019
*@version 1.0
*/

package fa.appcode.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ErrorController {
  
  @RequestMapping("/errorpage")
  public String errorPage(HttpServletRequest httpServletRequest, Model theModel) {
    
    int httpErrorCode = getErrorCode(httpServletRequest);
    String errorMessage = "";
    
    switch (httpErrorCode) {
    case 404:
      errorMessage = "Http 404 Page Not Found!";
      break;
    case 400:
      errorMessage = "Http 400 Bad Request!";
      break;
    default:
      errorMessage = "HTTP " + httpErrorCode + " Error!";
      break;
    }
    
    theModel.addAttribute("errorMessage",errorMessage);
    
    return "errorpage";
  }
  
  
  private int getErrorCode(HttpServletRequest httpServletRequest) {
    return (int) httpServletRequest.getAttribute("javax.servlet.error.status_code");
  }
}
