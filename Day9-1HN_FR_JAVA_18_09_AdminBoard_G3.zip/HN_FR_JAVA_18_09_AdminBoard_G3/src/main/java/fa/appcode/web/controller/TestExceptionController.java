package fa.appcode.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestExceptionController {
  
  @RequestMapping("/testNullPointer")
  public void testNullPointerException() {
    
    throw new NullPointerException();
  }
  
  @RequestMapping("/testNullPointer2")
  public void testNullPointerException2() {
    
    throw new NullPointerException("We throw a null point exception 2");
  }
  
  @RequestMapping("/testException")
  public void testException() throws Exception {
    
    throw new Exception();
  }
  
  @RequestMapping("/testStackOverflowError")
  public void testStackOverflowError() {
    
    throw new StackOverflowError();
  }
  
}
