/*
 *HUST
 *09:38 Jan 16, 2019
 *MockProjectG3
 */
package fa.appcode.web.controller;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import fa.appcode.common.utility.Constants;
import fa.appcode.entity.AllowanceGroup;
import fa.appcode.entity.ClassBatch;
import fa.appcode.entity.Faculty;
import fa.appcode.entity.Milestone;
import fa.appcode.entity.MilestoneTopic;
import fa.appcode.entity.Topic;
import fa.appcode.entity.Trainee;
import fa.appcode.entity.TraineeProfile;
import fa.appcode.entity.University;
import fa.appcode.entity.Users;
import fa.appcode.service.ClassBatchService;
import fa.appcode.service.TraineeService;
import fa.appcode.service.UserService;

@Controller
public class TrainneController {
  @Autowired
  private TraineeService traineeService;
  
  @Autowired
  private UserService userService;
  
  @Autowired
  private ClassBatchService classBatchService;

  @RequestMapping(value = "/panel/home", method = RequestMethod.GET)
  public String searchTrainee(Model theModel) {
    
    List<ClassBatch> listClassBatch = classBatchService.getAllClassBatch();
    
    theModel.addAttribute("listClassBatch", listClassBatch);
    
    return "searchtrainee";
  }

  @RequestMapping(value = "/panel/trainee", method = RequestMethod.GET)
  public String trainee(Model model) {
    int totalPage = 0;
    List<TraineeProfile> traineeProfiles = null;
    TraineeProfile traineeProfile = new TraineeProfile();
    traineeProfile.setEmail("");
    traineeProfile.setFullName("");
    traineeProfile.setPhone("");
    traineeProfile.setAccount("");
    Hashtable<Integer, List<TraineeProfile>> hashtable = new Hashtable<>();
    try {
      hashtable = traineeService.searchAndPaging(traineeProfile, Constants.PAGE_SIZE,
          1);
    } catch (Exception e) {
      e.printStackTrace();
    }
    Iterator<Map.Entry<Integer, List<TraineeProfile>>> it = hashtable.entrySet()
        .iterator();
    while (it.hasNext()) {
      Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>> entry = (Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>>) it
          .next();
      totalPage = entry.getKey();
      traineeProfiles = entry.getValue();
    }
    model.addAttribute("totalPage", totalPage);
    model.addAttribute("traineeProfiles", traineeProfiles);
    return "trainee";
  }

  @RequestMapping(value = "/panel/searchAndPagingTrainee", method = RequestMethod.POST)
  public String addTrainee(@RequestBody TraineeProfile traineeProfile, Model model) {
    int totalPage = 0;
    System.out.println(traineeProfile.toString());
    List<TraineeProfile> traineeProfiles = null;
    Hashtable<Integer, List<TraineeProfile>> hashtable = new Hashtable<>();
    try {
      hashtable = traineeService.searchAndPaging(traineeProfile, Constants.PAGE_SIZE,
          1);
    } catch (Exception e) {
      e.printStackTrace();
    }
    Iterator<Map.Entry<Integer, List<TraineeProfile>>> it = hashtable.entrySet()
        .iterator();
    while (it.hasNext()) {
      Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>> entry = (Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>>) it
          .next();
      totalPage = entry.getKey();
      traineeProfiles = entry.getValue();
    }
    model.addAttribute("totalPage", totalPage);
    model.addAttribute("traineeProfiles", traineeProfiles);
    model.addAttribute("traineeProfile", traineeProfile);
    return "trainee";
  }
  
  
  @RequestMapping(value = "/panel/searchAndPagingTrainee/{page}/{pagesize}", method = RequestMethod.GET)
  public String getTrainee(@PathVariable("page") int page,@PathVariable("pagesize") int pagesize, Model model) {
    int totalPage = 0;
    System.out.println("page = " + page);
    TraineeProfile traineeProfile = new TraineeProfile();
    traineeProfile.setAccount("");
    traineeProfile.setEmail("");
    traineeProfile.setFullName("");
    traineeProfile.setPhone("");
    System.out.println(traineeProfile.toString());
    List<TraineeProfile> traineeProfiles = null;
    Hashtable<Integer, List<TraineeProfile>> hashtable = new Hashtable<>();
    try {
      hashtable = traineeService.searchAndPaging(traineeProfile, pagesize,
          page);
    } catch (Exception e) {
      e.printStackTrace();
    }
    Iterator<Map.Entry<Integer, List<TraineeProfile>>> it = hashtable.entrySet()
        .iterator();
    while (it.hasNext()) {
      Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>> entry = (Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>>) it
          .next();
      totalPage = entry.getKey();
      traineeProfiles = entry.getValue();
    }
    model.addAttribute("totalPage", totalPage);
    model.addAttribute("traineeProfiles", traineeProfiles);
    model.addAttribute("pagesize", pagesize);
    model.addAttribute("page", page);
    return "trainee";
  }
  
  @RequestMapping(value = "/panel/changePageSize/{pagesize}", method = RequestMethod.GET)
  public String changePageSizeTrainee(@PathVariable("pagesize") int pagesize, Model model) {
    int totalPage = 0;
    System.out.println("pagesize = " + pagesize);
    TraineeProfile traineeProfile = new TraineeProfile();
    traineeProfile.setAccount("");
    traineeProfile.setEmail("");
    traineeProfile.setFullName("");
    traineeProfile.setPhone("");
    System.out.println(traineeProfile.toString());
    List<TraineeProfile> traineeProfiles = null;
    Hashtable<Integer, List<TraineeProfile>> hashtable = new Hashtable<>();
    try {
      hashtable = traineeService.searchAndPaging(traineeProfile, pagesize,
          1);
    } catch (Exception e) {
      e.printStackTrace();
    }
    Iterator<Map.Entry<Integer, List<TraineeProfile>>> it = hashtable.entrySet()
        .iterator();
    while (it.hasNext()) {
      Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>> entry = (Map.Entry<java.lang.Integer, java.util.List<TraineeProfile>>) it
          .next();
      totalPage = entry.getKey();
      traineeProfiles = entry.getValue();
    }
    model.addAttribute("totalPage", totalPage);
    model.addAttribute("traineeProfiles", traineeProfiles);
    model.addAttribute("pagesize", pagesize);
    return "trainee";
  }
  
  @RequestMapping(value = "/panel/updateTrainee1/{idTrainee}", method = RequestMethod.GET)
  public String updateTrainee(@PathVariable("idTrainee") int idTrainee,Model model) {
    Trainee trainee = null;
    List<University> listUniversity = null;
    List<Faculty> listFaculty = null;
    List<AllowanceGroup> listAllowanceGroup = null;
    
    Hashtable<Integer, String> hashtable = new Hashtable<>();
    try {
      trainee = traineeService.getTrainee(idTrainee);
      listUniversity = traineeService.getListUniversity();
      listFaculty = traineeService.getListFaculty();
      listAllowanceGroup = traineeService.getListAllowanceGroup();
    } catch (Exception e) {
      e.printStackTrace();
    }
    List<Topic> topics = null;
    try {
      topics = traineeService.findAllTopic();
      for (Topic topic : topics) {
        hashtable.put(topic.getTopicId(), topic.getTopicName());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    UserDetails userDetail = (UserDetails) auth.getPrincipal();
    Users theUsers = userService.getUser(userDetail.getUsername());
    
    
    
    model.addAttribute("trainee", trainee);
    model.addAttribute("topics", topics);
    model.addAttribute("listUniversity", listUniversity);
    model.addAttribute("listFaculty", listFaculty);
    model.addAttribute("listAllowanceGroup", listAllowanceGroup);
    model.addAttribute("userId", theUsers.getId());
    
    return "updateTrainee2";
  }
  
  @RequestMapping(value = "/panel/updateTrainee/{idTrainee}",produces = "application/json")
  public @ResponseBody Trainee getAllClassBatch(@PathVariable("idTrainee") int idTrainee){
    Trainee trainee = null;
    try {
       trainee = traineeService.getTrainee(idTrainee);
       System.out.println("trainee " + trainee);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return trainee;
  }
  
  @RequestMapping(value = "/panel/updateTraineeHehe/{idTrainee}",produces = "application/json")
  public @ResponseBody Trainee getAllClassBatchHehe(@PathVariable("idTrainee") int idTrainee){
    Trainee trainee = null;
    try {
       trainee = traineeService.getTrainee(idTrainee);
       System.out.println("trainee " + trainee);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return trainee;
  }
  

  
  @RequestMapping(value = "/panel/updateMile", method = RequestMethod.POST)
  public String updateMile(@RequestBody Trainee trainee) {
    System.out.println("trainee mile = " + trainee.toString());
//    List<Milestone> milestones1 =  trainee.getMilestones();
//    for (Milestone milestone : milestones1) {
//      List<MilestoneTopic> milestoneTopics =  milestone.getMilestoneTopics();
//      for (MilestoneTopic milestoneTopic : milestoneTopics) {
//        milestoneTopic.setMilestone(milestone);
//        break;
//      }
//    }
    try {
      traineeService.updateTrainee(trainee);
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
//    try {
//      List<Milestone> milestones = trainee.getMilestones();
//      for (Milestone milestone : milestones) {
//        milestone.setTrainee(trainee);
//      }
//      traineeService.updateTrainee(trainee);
//    } catch (Exception e) {
//      e.printStackTrace();
//    }
    return "updateTrainee2";
  }
  
  @RequestMapping(value = "/panel/viewTrainee/{idTrainee}", method = RequestMethod.GET)
  public String modeViewTrainee(@PathVariable("idTrainee") int idTrainee,Model model) {
    Trainee trainee = null;
    try {
      trainee = traineeService.getTrainee(idTrainee);
    } catch (Exception e) {
      e.printStackTrace();
    }
    System.out.println("modeViewTrainee");
    model.addAttribute("trainee", trainee);
    return "traineeProfile2";
  }
  
  @RequestMapping(value = "/panel/viewTrainee1/{idTrainee}",produces = "application/json")
  public @ResponseBody Trainee viewTrainee(@PathVariable("idTrainee") int idTrainee){
    Trainee trainee = null;
    try {
       trainee = traineeService.getTrainee(idTrainee);
       System.out.println("trainee viewTrainee " + trainee);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return trainee;
  }
  
  @RequestMapping(value = "/panel/delete/{milestoneIdRemove}")
  public @ResponseBody String deleteMilestone(@PathVariable("milestoneIdRemove") int milestoneIdRemove){
    System.out.println("milestoneIdRemove " + milestoneIdRemove);
    if (milestoneIdRemove != 0) {
      traineeService.deleteMilestone(milestoneIdRemove);
      return "ok";
    }
    return "chua co trong db";
    
  }
  
  @RequestMapping(value = "/panel/deleteTopic/{milestoneTopicIdRemove}")
  public @ResponseBody String deleteMilestoneTopic(@PathVariable("milestoneTopicIdRemove") int milestoneTopicIdRemove){
    if (milestoneTopicIdRemove != 0) {
      traineeService.deleteMilestoneTopic(milestoneTopicIdRemove);
      return "ok";
    }
    return "chua co trong db";
    
  }
  
  @RequestMapping(value = "/panel/updateTraineeProfile", method = RequestMethod.POST)
  public String updateTrainee(@RequestBody Trainee trainee) {
    System.out.println("Update Trainee Controller Data = " + trainee.toString());
    
    
      try {

        
        
        traineeService.updateTraineeProfile(trainee);
      } catch (Exception e) {
        e.printStackTrace();
      }

    return "updateTrainee2";
  }
  
}

