package fa.appcode.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import fa.appcode.entity.ClassBatch;
import fa.appcode.entity.TestEntityHi;
import fa.appcode.service.ClassBatchService;

@Controller
@RequestMapping("/panel")
public class HomeController {

  @Autowired
  private ClassBatchService classBatchService;
  
  @RequestMapping("/index")
  public String index(Model theModel) {
    
    List<ClassBatch> listClassBatch = classBatchService.getAllClassBatch();
    
    theModel.addAttribute("listClassBatch", listClassBatch);
    
    return "index";
  }
  
  @RequestMapping(value="/getAllClassBatch", produces = "application/json")
  public @ResponseBody List<ClassBatch> getAllClassBatch(){
    return classBatchService.getAllClassBatch();
  }
  
  
  @RequestMapping(value="/getTestEntityHi", produces = "application/json")
  public @ResponseBody TestEntityHi getTestEntity(){
    return new TestEntityHi("Hola", "halo@gmail.com");
  }
  
}
