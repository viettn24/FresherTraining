package fa.appcode.web.controller;

import java.sql.SQLException;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

  @ExceptionHandler(Exception.class)
  public String handlerException(Exception exc, Model theModel) {
    
    String exceptionInMethod = exc.getStackTrace()[0].getMethodName();
    String exceptionMessage = exc.getMessage();
    String exceptionName = exc.getClass().getSimpleName();
    
    theModel.addAttribute("exceptionMessage", exceptionMessage);
    theModel.addAttribute("exceptionInMethod", exceptionInMethod);
    theModel.addAttribute("exceptionName", exceptionName);
    
    
    return "exceptionpage";
  }
}
