/*
*@author tiennv29
*@date Jan 14, 2019
*@version 1.0
*/

package fa.appcode.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SecurityController {

  @RequestMapping(value = { "/login", "/" })
  public String login(
      @RequestParam(value = "error", required = false) final String error,
      final Model model) {
    if (error != null) {
      model.addAttribute("message", "Sorry, your username or password is incorrect. Please try again!");
    }
    return "login";
  }

  @RequestMapping("/logout")
  public String logout(final Model model) {
    model.addAttribute("message", "Logged out!");
    return "login";
  }
}
