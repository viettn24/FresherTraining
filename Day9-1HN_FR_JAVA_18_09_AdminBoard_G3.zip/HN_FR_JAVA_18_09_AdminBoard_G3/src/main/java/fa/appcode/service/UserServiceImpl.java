package fa.appcode.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fa.appcode.dao.UserDao;
import fa.appcode.entity.Users;

@Service
@Transactional
public class UserServiceImpl implements UserService {

  @Autowired
  private UserDao userDao;
  
  @Override
  public Users getUser(String username) {
    // TODO Auto-generated method stub
    return userDao.loadByUserName(username);
  }

}
