package fa.appcode.service;

import fa.appcode.entity.Users;

public interface UserService {
  public Users getUser(String username);
}
