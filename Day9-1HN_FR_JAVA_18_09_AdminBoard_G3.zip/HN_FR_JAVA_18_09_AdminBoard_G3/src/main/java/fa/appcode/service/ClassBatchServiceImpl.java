/*
*@author TienNV29
*@date Jan 16, 2019
*@version 1.0
*/

package fa.appcode.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fa.appcode.dao.ClassBatchDao;
import fa.appcode.entity.ClassBatch;

@Service
public class ClassBatchServiceImpl implements ClassBatchService {

  @Autowired
  private ClassBatchDao classBatchDao;
  
  @Override
  @Transactional
  public List<ClassBatch> getAllClassBatch() {
    
    return classBatchDao.getAllClassBatch();
  }

}
