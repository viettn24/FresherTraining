/*
 *HUST
 *Jan 13, 2019
 *MockProjectG3
 */
package fa.appcode.service;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fa.appcode.dao.TraineeDao;
import fa.appcode.entity.AllowanceGroup;
import fa.appcode.entity.Faculty;
import fa.appcode.entity.History;
import fa.appcode.entity.Topic;
import fa.appcode.entity.Trainee;
import fa.appcode.entity.TraineeProfile;
import fa.appcode.entity.University;

@Service
public class TraineeServiceImpl implements TraineeService {

  @Autowired
  private TraineeDao traineeDao;

  @Override
  @Transactional
  public Hashtable<Integer, List<TraineeProfile>> searchAndPaging(
      TraineeProfile traineeProfile, int pageSize, int pageNumber)
      throws Exception {
    return traineeDao.searchAndPaging(traineeProfile, pageSize, pageNumber);
  }

  @Override
  @Transactional
  public List<Trainee> findAll() throws Exception {
    return traineeDao.findAll();
  }

  @Override
  @Transactional
  public Trainee getTrainee(int idTrainee) throws Exception {
    return traineeDao.getTrainee(idTrainee);
  }

  @Override
  @Transactional
  public boolean updateTrainee(Trainee trainee) throws Exception {
    return traineeDao.updateTrainee(trainee);
  }

  @Override
  @Transactional
  public List<Topic> findAllTopic() throws Exception {
    return traineeDao.findAllTopic();
  }

  @Override
  @Transactional
  public List<University> getListUniversity() {
    // TODO Auto-generated method stub
    return traineeDao.getListUniversity();
  }

  @Override
  @Transactional
  public List<Faculty> getListFaculty() {
    // TODO Auto-generated method stub
    return traineeDao.getListFaculty();
  }

  @Override
  @Transactional
  public List<AllowanceGroup> getListAllowanceGroup() {
    // TODO Auto-generated method stub
    return traineeDao.getListAllowanceGroup();
  }

  @Override
  @Transactional
  public void deleteMilestone(int milestoneIdRemove) {
    traineeDao.deleteMilestone(milestoneIdRemove);

  }

  @Override
  @Transactional
  public void deleteMilestoneTopic(int milestoneTopicIdRemove) {
    traineeDao.deleteMilestoneTopic(milestoneTopicIdRemove);
  }
  
  @Override
  @Transactional
  public boolean updateTraineeProfile(Trainee trainee) throws Exception {
    List<History> listHistoryByTraineeId;
    
    if (trainee.getTraineeId() != 0) {
      listHistoryByTraineeId = traineeDao.listHistoryByTraineeId(trainee.getTraineeId());
    } else {
      listHistoryByTraineeId = new ArrayList<>();
    }
    
    listHistoryByTraineeId.add(trainee.getListHistory().get(0));
    trainee.setListHistory(listHistoryByTraineeId);
    
    Trainee traineeInDatabase = traineeDao.getTrainee(trainee.getTraineeId());
    TraineeProfile traineeProfileInDataBase = traineeInDatabase.getTraineeProfiles();
    TraineeProfile traineeProfile = trainee.getTraineeProfiles();
    
    traineeProfile.setAccount(traineeProfileInDataBase.getAccount());
    traineeProfile.setType(traineeProfileInDataBase.getType());
    traineeProfile.setCreatedDate(traineeProfileInDataBase.getCreatedDate());
    
    trainee.setTraineeProfiles(traineeProfile);
    trainee.setStatusId(traineeInDatabase.getStatusId());
    trainee.setAllocationStatus(traineeInDatabase.getAllocationStatus());
    trainee.setMilestones(traineeInDatabase.getMilestones());
    
    
    return traineeDao.updateTraineeProfile(trainee);
  }

}
