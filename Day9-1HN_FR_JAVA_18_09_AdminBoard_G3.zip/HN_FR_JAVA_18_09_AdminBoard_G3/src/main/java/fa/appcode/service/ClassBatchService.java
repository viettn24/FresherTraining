/*
*@author TienNV29
*@date Jan 16, 2019
*@version 1.0
*/

package fa.appcode.service;

import java.util.List;

import fa.appcode.entity.ClassBatch;

public interface ClassBatchService {
  public List<ClassBatch> getAllClassBatch();
}
