/*
*@author tiennv29
*@date Jan 14, 2019
*@version 1.0
*/

package fa.appcode.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import fa.appcode.dao.UserDao;
import fa.appcode.entity.Users;

@Service
public class MyUserDetailsService implements UserDetailsService {

  @Autowired
  private UserDao userDao;
  
  
  @Override
  @Transactional
  public UserDetails loadUserByUsername(String username)
      throws UsernameNotFoundException {

    Users theUsers = userDao.loadByUserName(username);
    
    if(theUsers == null) {
      return null;
    }
    
    boolean enabled = true;
    boolean accountNonExpired = true;
    boolean credentialsNonExpired = true;
    boolean accountNonLocked = true;

    return new User(username, theUsers.getPassword(), enabled, accountNonExpired, credentialsNonExpired,
        accountNonLocked, theUsers.getAuthorities());
    
  }

}
