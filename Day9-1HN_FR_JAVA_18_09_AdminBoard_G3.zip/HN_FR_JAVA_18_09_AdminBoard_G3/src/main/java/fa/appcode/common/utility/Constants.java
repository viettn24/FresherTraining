/*
 *HUST
 *Jan 14, 2019
 *MockProjectG3
 */
package fa.appcode.common.utility;

public class Constants {
  public static final int PAGE_SIZE = 10;
}
