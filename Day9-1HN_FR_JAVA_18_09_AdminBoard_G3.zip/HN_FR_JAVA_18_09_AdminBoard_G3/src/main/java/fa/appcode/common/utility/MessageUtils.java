/*
 * (C) Copyright 2019 Fresher Academy
 *
 * @author GiangNQ4
 * @date Jan 25, 2019
 * @version 1.0
 */

package fa.appcode.common.utility;

import java.io.IOException;
import java.util.Properties;

public class MessageUtils {
  /**
   * This method is get message from message code.
   * 
   * @param message
   * @return String content message.
   * @throws IOException
   */
  public static String getMessage(String messageCode) throws IOException {
    Properties properties = new Properties();
    properties
        .load(MessageUtils.class.getResourceAsStream("/message.properties"));
    return properties.getProperty(messageCode);
  }
}
