/**
 * 
 */
/**
 * @author GiangNQ4
 *
 */
package fa.appcode.common.valueobjects;