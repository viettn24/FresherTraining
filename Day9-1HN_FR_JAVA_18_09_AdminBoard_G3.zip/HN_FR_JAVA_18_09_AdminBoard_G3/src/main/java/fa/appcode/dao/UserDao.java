/*
*@author TienNV29
*@date Jan 15, 2019
*@version 1.0
*/

package fa.appcode.dao;

import fa.appcode.entity.Users;

public interface UserDao {
  public Users loadByUserName(String username);
}
