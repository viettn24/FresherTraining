/*
*@author TienNV29
*@date Jan 16, 2019
*@version 1.0
*/

package fa.appcode.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fa.appcode.entity.ClassBatch;

@Repository
public class ClassBatchDaoImpl implements ClassBatchDao {

  @Autowired
  private SessionFactory sessionFactory;
  
  @Override
  public List<ClassBatch> getAllClassBatch() {
    
    Session session = sessionFactory.getCurrentSession();
    
    List<ClassBatch> listClassBatch = session.createQuery("FROM ClassBatch").getResultList();
    
    return listClassBatch;
  }

}
