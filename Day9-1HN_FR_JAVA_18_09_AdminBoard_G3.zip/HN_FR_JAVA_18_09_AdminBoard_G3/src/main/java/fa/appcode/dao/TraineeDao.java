/*
 *HUST
 *Jan 13, 2019
 *MockProjectG3
 */
package fa.appcode.dao;

import java.util.Hashtable;
import java.util.List;

import fa.appcode.entity.AllowanceGroup;
import fa.appcode.entity.Faculty;
import fa.appcode.entity.History;
import fa.appcode.entity.Topic;
import fa.appcode.entity.Trainee;
import fa.appcode.entity.TraineeProfile;
import fa.appcode.entity.University;

public interface TraineeDao {
  public Hashtable<Integer, List<TraineeProfile>> searchAndPaging(
      TraineeProfile traineeProfile, int pageSize, int pageNumber)
      throws Exception;

  public List<Trainee> findAll() throws Exception;

  public List<Topic> findAllTopic() throws Exception;

  public Trainee getTrainee(int idTrainee) throws Exception;

  public boolean updateTrainee(Trainee trainee) throws Exception;

  public List<University> getListUniversity();

  public List<Faculty> getListFaculty();

  public List<AllowanceGroup> getListAllowanceGroup();

  public List<History> listHistoryByTraineeId(int traineeId);

  public void deleteMilestone(int milestoneIdRemove);

  public void deleteMilestoneTopic(int milestoneTopicIdRemove);
  
  public boolean updateTraineeProfile(Trainee trainee) throws Exception;
}
