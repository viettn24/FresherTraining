/*
 *HUST
 *Jan 13, 2019
 *MockProjectG3
 */
package fa.appcode.dao;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fa.appcode.entity.AllowanceGroup;
import fa.appcode.entity.Faculty;
import fa.appcode.entity.History;
import fa.appcode.entity.Milestone;
import fa.appcode.entity.MilestoneTopic;
import fa.appcode.entity.Topic;
import fa.appcode.entity.Trainee;
import fa.appcode.entity.TraineeProfile;
import fa.appcode.entity.University;

@Repository
public class TraineeDaoImpl implements TraineeDao {
  @Autowired
  private SessionFactory sessionFactory;

  @Override
  public Hashtable<Integer, List<TraineeProfile>> searchAndPaging(
      TraineeProfile traineeProfile, int pageSize, int pageNumber) {
    Hashtable<Integer, List<TraineeProfile>> hashtable = new Hashtable<>();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    List<TraineeProfile> traineeProfiles = new ArrayList<>();
    Session session = sessionFactory.getCurrentSession();
    StoredProcedureQuery storedProcedureQuery = session
        .createNamedStoredProcedureQuery("findByPage");
    storedProcedureQuery.setParameter("PageSize", pageSize);
    storedProcedureQuery.setParameter("PageNumber", pageNumber);
    storedProcedureQuery.setParameter("emplId",
        traineeProfile.getTraineeProfileId());
    String dateOfBirth = null;
    if (traineeProfile.getDob() == null) {
      dateOfBirth = "";
    } else {
      dateOfBirth = traineeProfile.getDob().toString();
    }
    storedProcedureQuery.setParameter("dob", dateOfBirth);
    storedProcedureQuery.setParameter("account", traineeProfile.getAccount());
    storedProcedureQuery.setParameter("phone", traineeProfile.getPhone());
    storedProcedureQuery.setParameter("fullName", traineeProfile.getFullName());
    storedProcedureQuery.setParameter("email", traineeProfile.getEmail());
    traineeProfiles = storedProcedureQuery.getResultList();
    int totalRow = (int) storedProcedureQuery
        .getOutputParameterValue("totalrow");
    System.out.println("totalRow " + totalRow);
    hashtable.put(totalRow, traineeProfiles);
    return hashtable;
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<Trainee> findAll() {
    Session session = sessionFactory.getCurrentSession();
    String sqlFindAll = "FROM Trainee";
    Query query = session.createQuery(sqlFindAll);
    List<Trainee> trainees = query.list();
    return trainees;
  }

  @Override
  public Trainee getTrainee(int idTrainee) throws Exception {
    Session session = sessionFactory.getCurrentSession();
    String hql = "FROM Trainee WHERE id = :id";
    Query query = session.createQuery(hql);
    query.setParameter("id", idTrainee);
    Trainee trainee = (Trainee) query.list().get(0);
    session.clear();
    return trainee;
  }

  @Override
  public boolean updateTrainee(Trainee trainee) throws Exception {
    Session session = sessionFactory.getCurrentSession();
    try {
      session.saveOrUpdate(trainee);
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    } 
    return true;
  }

  @Override
  public List<Topic> findAllTopic() throws Exception {
    Session session = sessionFactory.getCurrentSession();
    String hql = "FROM Topic";
    Query query = session.createQuery(hql);
    return query.list();
  }

  @Override
  public List<University> getListUniversity() {
    Session session = sessionFactory.getCurrentSession();
    List<University> listUniversity = session.createQuery("FROM University")
        .getResultList();
    return listUniversity;
  }

  @Override
  public List<Faculty> getListFaculty() {
    Session session = sessionFactory.getCurrentSession();
    List<Faculty> listFaculty = session.createQuery("FROM Faculty")
        .getResultList();
    return listFaculty;
  }

  @Override
  public List<AllowanceGroup> getListAllowanceGroup() {
    Session session = sessionFactory.getCurrentSession();
    List<AllowanceGroup> listAllowanceGroup = session
        .createQuery("FROM AllowanceGroup").getResultList();
    return listAllowanceGroup;
  }

  @Override
  public List<History> listHistoryByTraineeId(int traineeId) {
    Session session = sessionFactory.getCurrentSession();
    Query theQuery = session
        .createQuery("FROM History h WHERE h.traineeId= :theTraineeId");
    theQuery.setParameter("theTraineeId", new Trainee(traineeId));
    List<History> listHistoryByTraineeId = theQuery.getResultList();
    return listHistoryByTraineeId;
  }

  @Override
  public void deleteMilestone(int milestoneIdRemove) {
    Session session = sessionFactory.getCurrentSession();
    Milestone milestone = new Milestone();
    milestone.setMilestoneId(milestoneIdRemove);
    session.delete(milestone);
  }

  @Override
  public void deleteMilestoneTopic(int milestoneTopicIdRemove) {
    Session session = sessionFactory.getCurrentSession();
    MilestoneTopic milestoneTopic = new MilestoneTopic();
    milestoneTopic.setMilestoneId(milestoneTopicIdRemove);
    session.delete(milestoneTopic);
  }
  
  @Override
  public boolean updateTraineeProfile(Trainee trainee) {
    try {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      session.update(trainee);
      session.getTransaction().commit();
      session.close();
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
    return true;
  }
}
