/*
*@author tiennv29
*@date Jan 14, 2019
*@version 1.0
*/

package fa.appcode.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fa.appcode.entity.Users;


@Repository
public class UserDaoImpl implements UserDao{

  @Autowired
  private SessionFactory sessionFactory;
  
  public Users loadByUserName(String username) {
    Session session = sessionFactory.getCurrentSession();
    
    Query theQuery = session.createQuery("FROM Users WHERE username= :theUsername");
    theQuery.setParameter("theUsername", username);
    
    Users theUsers = (Users) theQuery.getSingleResult();
    
    
    return theUsers;
    
  }
  
  
  
}
