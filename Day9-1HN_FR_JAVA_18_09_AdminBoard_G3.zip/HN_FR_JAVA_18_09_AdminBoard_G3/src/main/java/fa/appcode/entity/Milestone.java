/*
 * (C) Copyright 2019 Fresher Academy
 *
 * @author GiangNQ4
 * @date Jan 16, 2019
 * @version 1.0
 */

package fa.appcode.entity;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Milestone", schema = "giangnq4")
public class Milestone implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "milestone_id")
  private int milestoneId;
  @Column(name = "milestone_name")
  private String milestoneName;
  @Column(name = "salary_paid")
  private String salaryPaid;
  @Column(name = "startDate", columnDefinition = "date")
  private Date startDate;
  @Column(name = "endDate", columnDefinition = "date")
  private Date endDate;

  @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name="milestone_id")
  @Fetch(FetchMode.SELECT)
  private List<MilestoneTopic> milestoneTopics;

  @ManyToOne
  @JoinColumn(name = "trainee_id",updatable=false,insertable=true)
  @JsonBackReference
  private Trainee trainee;

  public Milestone() {
    super();
  }

  public Milestone(int milestoneId, String milestoneName, String salaryPaid,
      Date startDate, Date endDate, List<MilestoneTopic> milestoneTopics,
      Trainee trainee) {
    super();
    this.milestoneId = milestoneId;
    this.milestoneName = milestoneName;
    this.salaryPaid = salaryPaid;
    this.startDate = startDate;
    this.endDate = endDate;
    this.milestoneTopics = milestoneTopics;
    this.trainee = trainee;
  }

  public int getMilestoneId() {
    return milestoneId;
  }

  public void setMilestoneId(int milestoneId) {
    this.milestoneId = milestoneId;
  }

  public String getMilestoneName() {
    return milestoneName;
  }

  public void setMilestoneName(String milestoneName) {
    this.milestoneName = milestoneName;
  }

  public String getSalaryPaid() {
    return salaryPaid;
  }

  public void setSalaryPaid(String salaryPaid) {
    this.salaryPaid = salaryPaid;
  }

  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  public List<MilestoneTopic> getMilestoneTopics() {
    return milestoneTopics;
  }

  public void setMilestoneTopics(List<MilestoneTopic> milestoneTopics) {
    this.milestoneTopics = milestoneTopics;
  }

  public Trainee getTrainee() {
    return trainee;
  }

  public void setTrainee(Trainee trainee) {
    this.trainee = trainee;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "Milestone [milestoneId=" + milestoneId + ", milestoneName="
        + milestoneName + ", salaryPaid=" + salaryPaid + ", startDate="
        + startDate + ", endDate=" + endDate + ", milestoneTopics="
        + milestoneTopics + "]";
  }

}
