/*
*@author tiennv29
*@date Jan 14, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "users", schema = "TienNV29")
public class Users {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private int id;

  @Column(name = "username", unique = true)
  private String username;

  @Column(name = "password")
  private String password;

  @Column(name = "enabled")
  private String enabled;

  @ManyToMany(fetch=FetchType.EAGER)
  @Fetch(FetchMode.SELECT)
  @JoinTable(name = "users_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"), schema = "TienNV29")
  private List<Role> roleId;

  @OneToMany(mappedBy = "userModifiedId")
  @JsonBackReference
  private List<History> listModifiedUserHistory;

  public Users() {
  }

  public Users(int id) {
    this.id = id;
  }

  public Users(int id, String username, String password, String enabled,
      List<Role> roleId, List<History> listModifiedUserHistory) {
    this.id = id;
    this.username = username;
    this.password = password;
    this.enabled = enabled;
    this.roleId = roleId;
    this.listModifiedUserHistory = listModifiedUserHistory;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getEnabled() {
    return enabled;
  }

  public void setEnabled(String enabled) {
    this.enabled = enabled;
  }

  public List<Role> getRoleId() {
    return roleId;
  }

  public void setRoleId(List<Role> roleId) {
    this.roleId = roleId;
  }

  public List<History> getListModifiedUserHistory() {
    return listModifiedUserHistory;
  }

  public void setListModifiedUserHistory(
      List<History> listModifiedUserHistory) {
    this.listModifiedUserHistory = listModifiedUserHistory;
  }

  @Override
  public String toString() {
    return "Users [id=" + id + ", username=" + username + "]";
  }

  @Transient
  public List<GrantedAuthority> getAuthorities() {
    List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
    for (Role tempRole : this.roleId) {
      authorities.add(new SimpleGrantedAuthority(tempRole.getName()));
    }
    return authorities;
  }

}
