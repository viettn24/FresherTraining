/*
*@author TienNV29
*@date Jan 22, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "AllowanceGroup", schema = "Trainee")
public class AllowanceGroup {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "allowance_group_id")
  private int allowanceGroupId;

  @Column(name = "allowance_group_name")
  private String allowanceGroupName;

  @OneToMany(cascade = CascadeType.ALL, mappedBy="allowanceGroupId")
  @JsonBackReference
  private List<Trainee> listTrainee;

  public AllowanceGroup() {
    super();
  }

  public AllowanceGroup(int allowanceGroupId, String allowanceGroupName,
      List<Trainee> listTrainee) {
    super();
    this.allowanceGroupId = allowanceGroupId;
    this.allowanceGroupName = allowanceGroupName;
    this.listTrainee = listTrainee;
  }

  public int getAllowanceGroupId() {
    return allowanceGroupId;
  }

  public void setAllowanceGroupId(int allowanceGroupId) {
    this.allowanceGroupId = allowanceGroupId;
  }

  public String getAllowanceGroupName() {
    return allowanceGroupName;
  }

  public void setAllowanceGroupName(String allowanceGroupName) {
    this.allowanceGroupName = allowanceGroupName;
  }

  public List<Trainee> getListTrainee() {
    return listTrainee;
  }

  public void setListTrainee(List<Trainee> listTrainee) {
    this.listTrainee = listTrainee;
  }

  @Override
  public String toString() {
    return "AllowanceGroup [allowanceGroupId=" + allowanceGroupId
        + ", allowanceGroupName=" + allowanceGroupName + "]";
  }

}
