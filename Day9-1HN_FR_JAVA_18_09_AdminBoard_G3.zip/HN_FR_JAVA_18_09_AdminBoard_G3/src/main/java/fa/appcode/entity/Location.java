/*
*@author TienNV29
*@date Jan 16, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "Location", schema = "Trainee")
public class Location {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "location_id")
  private int locationId;

  @Column(name = "location_name")
  private String locationName;

  @OneToMany(mappedBy = "locationId", fetch = FetchType.EAGER)
  @JsonBackReference
  private List<ClassBatch> classBatch;

  public Location() {
  }

  public Location(int locationId, String locationName,
      List<ClassBatch> classBatch) {
    this.locationId = locationId;
    this.locationName = locationName;
    this.classBatch = classBatch;
  }

  public int getLocationId() {
    return locationId;
  }

  public void setLocationId(int locationId) {
    this.locationId = locationId;
  }

  public String getLocationName() {
    return locationName;
  }

  public void setLocationName(String locationName) {
    this.locationName = locationName;
  }

  public List<ClassBatch> getClassBatch() {
    return classBatch;
  }

  public void setClassBatch(List<ClassBatch> classBatch) {
    this.classBatch = classBatch;
  }

  @Override
  public String toString() {
    return "Location [locationId=" + locationId + ", locationName="
        + locationName + "]";
  }

}
