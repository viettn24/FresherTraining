/*
*@author TienNV29
*@date Jan 22, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "University", schema = "Trainee")
public class University {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "university_id")
  private int universityId;

  @Column(name = "university_name")
  private String universityName;

  @OneToMany(mappedBy = "universityId")
  @JsonBackReference
  private List<TraineeProfile> listTraineeProfile;

  public University() {
  }

  public University(int universityId, String universityName,
      List<TraineeProfile> listTraineeProfile) {
    this.universityId = universityId;
    this.universityName = universityName;
    this.listTraineeProfile = listTraineeProfile;
  }

  public int getUniversityId() {
    return universityId;
  }

  public void setUniversityId(int universityId) {
    this.universityId = universityId;
  }

  public String getUniversityName() {
    return universityName;
  }

  public void setUniversityName(String universityName) {
    this.universityName = universityName;
  }

  public List<TraineeProfile> getListTraineeProfile() {
    return listTraineeProfile;
  }

  public void setListTraineeProfile(List<TraineeProfile> listTraineeProfile) {
    this.listTraineeProfile = listTraineeProfile;
  }

  @Override
  public String toString() {
    return "University [universityId=" + universityId + ", universityName="
        + universityName + "]";
  }

}
