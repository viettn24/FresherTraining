/*
 * (C) Copyright 2019 Fresher Academy
 *
 * @author GiangNQ4
 * @date Jan 16, 2019
 * @version 1.0
 */

package fa.appcode.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Milestone_Topic", schema = "giangnq4")
public class MilestoneTopic implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "milestone_topic_id")
  private int milestoneId;
  @Column(name = "max_score")
  private int max_score;
  @Column(name = "passing_score")
  private int passingScore;
  @Column(name = "weighted_number")
  private int weightedNumber;
  // @ManyToOne(fetch = FetchType.EAGER)
  // @JoinColumn(name = "milestone_id", referencedColumnName = "milestone_id")
  // private Milestone milestone;
  // @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  // @JoinColumn(name = "topic_id", referencedColumnName = "topic_id",
  // insertable = false, updatable = false)
  // @JoinColumn(name = "topic_id1")

  @ManyToOne
  @JoinColumn(name = "milestone_id", updatable = false, insertable = true)
  @JsonBackReference
  @Fetch(FetchMode.SELECT)
  private Milestone milestone;

  @ManyToOne
  @JoinColumn(name = "topic_id",insertable = true)
  private Topic topic;

  public MilestoneTopic() {
    super();
  }

  public MilestoneTopic(int milestoneId, int max_score, int passingScore,
      int weightedNumber, Milestone milestone, Topic topic) {
    super();
    this.milestoneId = milestoneId;
    this.max_score = max_score;
    this.passingScore = passingScore;
    this.weightedNumber = weightedNumber;
    this.milestone = milestone;
    this.topic = topic;
  }

  public int getMilestoneId() {
    return milestoneId;
  }

  public void setMilestoneId(int milestoneId) {
    this.milestoneId = milestoneId;
  }

  public int getMax_score() {
    return max_score;
  }

  public void setMax_score(int max_score) {
    this.max_score = max_score;
  }

  public int getPassingScore() {
    return passingScore;
  }

  public void setPassingScore(int passingScore) {
    this.passingScore = passingScore;
  }

  public int getWeightedNumber() {
    return weightedNumber;
  }

  public void setWeightedNumber(int weightedNumber) {
    this.weightedNumber = weightedNumber;
  }

  public Milestone getMilestone() {
    return milestone;
  }

  public void setMilestone(Milestone milestone) {
    this.milestone = milestone;
  }

  public Topic getTopic() {
    return topic;
  }

  public void setTopic(Topic topic) {
    this.topic = topic;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "MilestoneTopic [milestoneId=" + milestoneId + ", max_score="
        + max_score + ", passingScore=" + passingScore + ", weightedNumber="
        + weightedNumber + ", topic=" + topic + "]";
  }

}
