/*
 *HUST
 *Jan 13, 2019
 *MockProjectG3
 */
package fa.appcode.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "Trainee", schema = "giangnq4")
public class Trainee implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "trainee_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int traineeId;

  @Column(name = "salary_paid")
  private String salaryPaid;

  @Column(name = "class_id")
  private int classId;

  @Column(name = "attendance_status_id")
  private int attendanceStatusId;

  @Column(name = "status_id")
  private String statusId;

  @Column(name = "allocation_status")
  private String allocationStatus;

  @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinColumn(name = "allowance_group_id")
  private AllowanceGroup allowanceGroupId;

  @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "trainee_profile_id", unique = true)
  private TraineeProfile traineeProfiles;

  @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name="trainee_id")
  private List<Milestone> milestones;

  @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "trainee_id")
  @Fetch(FetchMode.SELECT)
  private List<History> listHistory;

  public Trainee() {
    super();
  }

  public Trainee(int traineeId) {
    this.traineeId = traineeId;
  }

  public Trainee(int traineeId, String salaryPaid, int classId,
      int attendanceStatusId, String statusId, String allocationStatus,
      AllowanceGroup allowanceGroupId, TraineeProfile traineeProfiles,
      List<Milestone> milestones, List<History> listHistory) {
    this.traineeId = traineeId;
    this.salaryPaid = salaryPaid;
    this.classId = classId;
    this.attendanceStatusId = attendanceStatusId;
    this.statusId = statusId;
    this.allocationStatus = allocationStatus;
    this.allowanceGroupId = allowanceGroupId;
    this.traineeProfiles = traineeProfiles;
    this.milestones = milestones;
    this.listHistory = listHistory;
  }

  public int getTraineeId() {
    return traineeId;
  }

  public void setTraineeId(int traineeId) {
    this.traineeId = traineeId;
  }

  public String getSalaryPaid() {
    return salaryPaid;
  }

  public void setSalaryPaid(String salaryPaid) {
    this.salaryPaid = salaryPaid;
  }

  public int getClassId() {
    return classId;
  }

  public void setClassId(int classId) {
    this.classId = classId;
  }

  public int getAttendanceStatusId() {
    return attendanceStatusId;
  }

  public void setAttendanceStatusId(int attendanceStatusId) {
    this.attendanceStatusId = attendanceStatusId;
  }

  public String getStatusId() {
    return statusId;
  }

  public void setStatusId(String statusId) {
    this.statusId = statusId;
  }

  public String getAllocationStatus() {
    return allocationStatus;
  }

  public void setAllocationStatus(String allocationStatus) {
    this.allocationStatus = allocationStatus;
  }

  public AllowanceGroup getAllowanceGroupId() {
    return allowanceGroupId;
  }

  public void setAllowanceGroupId(AllowanceGroup allowanceGroupId) {
    this.allowanceGroupId = allowanceGroupId;
  }

  public TraineeProfile getTraineeProfiles() {
    return traineeProfiles;
  }

  public void setTraineeProfiles(TraineeProfile traineeProfiles) {
    this.traineeProfiles = traineeProfiles;
  }

  public List<Milestone> getMilestones() {
    return milestones;
  }

  public void setMilestones(List<Milestone> milestones) {
    this.milestones = milestones;
  }

  public List<History> getListHistory() {
    return listHistory;
  }

  public void setListHistory(List<History> listHistory) {
    this.listHistory = listHistory;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "Trainee [traineeId=" + traineeId + ", salaryPaid=" + salaryPaid
        + ", classId=" + classId + ", attendanceStatusId=" + attendanceStatusId
        + ", statusId=" + statusId + ", allocationStatus=" + allocationStatus
        + ", allowanceGroupId=" + allowanceGroupId + ", traineeProfiles="
        + traineeProfiles + ", milestones=" + milestones + ", listHistory="
        + listHistory + "]";
  }

}
