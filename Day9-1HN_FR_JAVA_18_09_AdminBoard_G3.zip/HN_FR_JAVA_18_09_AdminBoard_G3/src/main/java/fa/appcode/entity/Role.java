/*
*@author tiennv29
*@date Jan 14, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "role", schema = "TienNV29")
public class Role {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private int id;

  @Column(name = "name")
  private String name;

  @ManyToMany
  @JsonBackReference
  @JoinTable(name = "users_roles", joinColumns = @JoinColumn(name = "role_id"), inverseJoinColumns = @JoinColumn(name = "user_id"), schema="TienNV29")
  private List<Users> userId;

  public Role() {
  }

  public Role(int id, String name, List<Users> userId) {
    this.id = id;
    this.name = name;
    this.userId = userId;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<Users> getUserId() {
    return userId;
  }

  public void setUserId(List<Users> userId) {
    this.userId = userId;
  }

  @Override
  public String toString() {
    return "Role [id=" + id + ", name=" + name + ", userId=" + userId + "]";
  }

}
