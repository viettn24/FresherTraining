/*
 * (C) Copyright 2019 Fresher Academy
 *
 * @author GiangNQ4
 * @date Jan 16, 2019
 * @version 1.0
 */

package fa.appcode.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Topic", schema = "giangnq4")
public class Topic implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "topic_id")
  private int topicId;
  @Column(name = "topic_name")
  private String topicName;

  @OneToMany(mappedBy = "topic",cascade=CascadeType.ALL)
  @JsonBackReference
  private List<MilestoneTopic> listMilestoneTopic;

  public Topic() {
    super();
  }

  public Topic(int topicId, String topicName,
      List<MilestoneTopic> listMilestoneTopic) {
    super();
    this.topicId = topicId;
    this.topicName = topicName;
    this.listMilestoneTopic = listMilestoneTopic;
  }

  public int getTopicId() {
    return topicId;
  }

  public void setTopicId(int topicId) {
    this.topicId = topicId;
  }

  public String getTopicName() {
    return topicName;
  }

  public void setTopicName(String topicName) {
    this.topicName = topicName;
  }

  public List<MilestoneTopic> getListMilestoneTopic() {
    return listMilestoneTopic;
  }

  public void setListMilestoneTopic(List<MilestoneTopic> listMilestoneTopic) {
    this.listMilestoneTopic = listMilestoneTopic;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "Topic [topicId=" + topicId + ", topicName=" + topicName + "]";
  }

}
