/*
*@author TienNV29
*@date Jan 16, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "ClassBatch", schema = "Trainee")
public class ClassBatch implements Serializable{

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "class_id")
  private int classId;

  @Column(name = "class_name")
  private String className;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "location_id")
  private Location locationId;

  @Column(name = "planed_trainee_number")
  private int planedTraineeNumber;

  @Column(name = "inprocess_trainee_number")
  private int inprogressTraineeNumber;

  @Column(name = "planning_trainee_number")
  private int planningTraineeNumber;

  @Column(name = "status")
  private int status;

  public ClassBatch() {
  }

  public ClassBatch(int classId, String className, Location locationId,
      int planedTraineeNumber, int inprogressTraineeNumber,
      int planningTraineeNumber, int status) {
    this.classId = classId;
    this.className = className;
    this.locationId = locationId;
    this.planedTraineeNumber = planedTraineeNumber;
    this.inprogressTraineeNumber = inprogressTraineeNumber;
    this.planningTraineeNumber = planningTraineeNumber;
    this.status = status;
  }

  public int getClassId() {
    return classId;
  }

  public void setClassId(int classId) {
    this.classId = classId;
  }

  public String getClassName() {
    return className;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public Location getLocationId() {
    return locationId;
  }

  public void setLocationId(Location locationId) {
    this.locationId = locationId;
  }

  public int getPlanedTraineeNumber() {
    return planedTraineeNumber;
  }

  public void setPlanedTraineeNumber(int planedTraineeNumber) {
    this.planedTraineeNumber = planedTraineeNumber;
  }

  public int getInprogressTraineeNumber() {
    return inprogressTraineeNumber;
  }

  public void setInprogressTraineeNumber(int inprogressTraineeNumber) {
    this.inprogressTraineeNumber = inprogressTraineeNumber;
  }

  public int getPlanningTraineeNumber() {
    return planningTraineeNumber;
  }

  public void setPlanningTraineeNumber(int planningTraineeNumber) {
    this.planningTraineeNumber = planningTraineeNumber;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return "ClassBatch [classId=" + classId + ", className=" + className
        + ", planedTraineeNumber=" + planedTraineeNumber
        + ", inprogressTraineeNumber=" + inprogressTraineeNumber
        + ", planningTraineeNumber=" + planningTraineeNumber + ", status="
        + status + "]";
  }



}
