/*
*@author TienNV29
*@date Jan 22, 2019
*@version 1.0
*/

package fa.appcode.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Faculty", schema = "Trainee")
public class Faculty {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "faculty_id")
  private int facultyId;

  @Column(name = "faculty_name")
  private String facultyName;

  @OneToMany(mappedBy = "facultyId")
  @JsonBackReference
  private List<TraineeProfile> listTraineeProfile;

  public Faculty() {
  }

  public Faculty(int facultyId, String facultyName,
      List<TraineeProfile> listTraineeProfile) {
    this.facultyId = facultyId;
    this.facultyName = facultyName;
    this.listTraineeProfile = listTraineeProfile;
  }

  public int getFacultyId() {
    return facultyId;
  }

  public void setFacultyId(int facultyId) {
    this.facultyId = facultyId;
  }

  public String getFacultyName() {
    return facultyName;
  }

  public void setFacultyName(String facultyName) {
    this.facultyName = facultyName;
  }

  public List<TraineeProfile> getListTraineeProfile() {
    return listTraineeProfile;
  }

  public void setListTraineeProfile(List<TraineeProfile> listTraineeProfile) {
    this.listTraineeProfile = listTraineeProfile;
  }

  @Override
  public String toString() {
    return "Faculty [facultyId=" + facultyId + ", facultyName=" + facultyName
        + "]";
  }

}
