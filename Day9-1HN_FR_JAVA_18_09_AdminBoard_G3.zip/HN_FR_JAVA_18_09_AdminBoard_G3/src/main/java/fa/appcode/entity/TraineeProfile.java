/*
 *HUST
 *Jan 17, 2019
 *HN_FR_JAVA_18_09_AdminBoard_G3
 */
package fa.appcode.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.OneToOne;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@NamedStoredProcedureQueries({
    @NamedStoredProcedureQuery(name = "findByPage", procedureName = "giangnq4.usp_searchPagingTrainee", resultClasses = TraineeProfile.class, parameters = {
        @StoredProcedureParameter(mode = ParameterMode.IN, type = Integer.class, name = "PageSize"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = Integer.class, name = "PageNumber"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = Integer.class, name = "emplId"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "dob"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "account"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "phone"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "fullName"),
        @StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "email"),
        @StoredProcedureParameter(mode = ParameterMode.OUT, type = Integer.class, name = "totalrow") }) })
@Table(name = "TraineeProfile", schema = "giangnq4")
public class TraineeProfile implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  @Id
  @Column(name = "profile_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int traineeProfileId;
  @Column(name = "fullname")
  private String fullName;
  @Column(name = "gender")
  private String gender;
  @Column(name = "email")
  private String email;
  @Column(name = "phone")
  private String phone;
  @Column(name = "account")
  private String account;
  @Column(name = "tpBank")
  private String tpBank;
  @Column(name = "type")
  private String type;
  @Column(name = "dob", columnDefinition = "date")
  private Date dob;
  @Column(name = "created_date", columnDefinition = "date")
  private Date createdDate;
  @Column(name = "updated_date", columnDefinition = "date")
  private Date updatedDate;

  @OneToOne(mappedBy = "traineeProfiles")
  @JsonBackReference
  private Trainee trainee;

  @ManyToOne(cascade=CascadeType.ALL)
  @JoinColumn(name = "university_id")
  private University universityId;

  @ManyToOne(cascade=CascadeType.ALL)
  @JoinColumn(name = "faculty_id")
  private Faculty facultyId;

  public TraineeProfile() {
  }

  public TraineeProfile(int traineeProfileId, String fullName, String gender,
      String email, String phone, String account, String tpBank, String type,
      Date dob, Date createdDate, Date updatedDate, Trainee trainee,
      University universityId, Faculty facultyId) {
    this.traineeProfileId = traineeProfileId;
    this.fullName = fullName;
    this.gender = gender;
    this.email = email;
    this.phone = phone;
    this.account = account;
    this.tpBank = tpBank;
    this.type = type;
    this.dob = dob;
    this.createdDate = createdDate;
    this.updatedDate = updatedDate;
    this.trainee = trainee;
    this.universityId = universityId;
    this.facultyId = facultyId;
  }

  public int getTraineeProfileId() {
    return traineeProfileId;
  }

  public void setTraineeProfileId(int traineeProfileId) {
    this.traineeProfileId = traineeProfileId;
  }

  public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getAccount() {
    return account;
  }

  public void setAccount(String account) {
    this.account = account;
  }

  public String getTpBank() {
    return tpBank;
  }

  public void setTpBank(String tpBank) {
    this.tpBank = tpBank;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Date getDob() {
    return dob;
  }

  public void setDob(Date dob) {
    this.dob = dob;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public Trainee getTrainee() {
    return trainee;
  }

  public void setTrainee(Trainee trainee) {
    this.trainee = trainee;
  }

  public University getUniversityId() {
    return universityId;
  }

  public void setUniversityId(University universityId) {
    this.universityId = universityId;
  }

  public Faculty getFacultyId() {
    return facultyId;
  }

  public void setFacultyId(Faculty facultyId) {
    this.facultyId = facultyId;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "TraineeProfile [traineeProfileId=" + traineeProfileId
        + ", fullName=" + fullName + ", gender=" + gender + ", email=" + email
        + ", phone=" + phone + ", account=" + account + ", tpBank=" + tpBank
        + ", type=" + type + ", dob=" + dob + ", createdDate=" + createdDate
        + ", updatedDate=" + updatedDate + ", universityId=" + universityId
        + ", facultyId=" + facultyId + "]";
  }

}
