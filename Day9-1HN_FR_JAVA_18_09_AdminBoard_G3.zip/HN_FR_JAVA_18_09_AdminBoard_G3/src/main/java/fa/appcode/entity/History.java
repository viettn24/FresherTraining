package fa.appcode.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "History", schema = "Trainee")
public class History {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "history_id")
  private int historyId;

  @Column(name = "history_change")
  private Date historyChange;

  @ManyToOne
  @JoinColumn(name = "trainee_id")
  @JsonBackReference
  private Trainee traineeId;

  @ManyToOne
  @JoinColumn(name = "user_modified_id")
  private Users userModifiedId;

  public History() {
  }

  public History(int historyId, Date historyChange, Trainee traineeId,
      Users userModifiedId) {
    this.historyId = historyId;
    this.historyChange = historyChange;
    this.traineeId = traineeId;
    this.userModifiedId = userModifiedId;
  }

  public int getHistoryId() {
    return historyId;
  }

  public void setHistoryId(int historyId) {
    this.historyId = historyId;
  }

  public Date getHistoryChange() {
    return historyChange;
  }

  public void setHistoryChange(Date historyChange) {
    this.historyChange = historyChange;
  }

  public Trainee getTraineeId() {
    return traineeId;
  }

  public void setTraineeId(Trainee traineeId) {
    this.traineeId = traineeId;
  }

  public Users getUserModifiedId() {
    return userModifiedId;
  }

  public void setUserModifiedId(Users userModifiedId) {
    this.userModifiedId = userModifiedId;
  }

  @Override
  public String toString() {
    return "History [historyId=" + historyId + ", historyChange="
        + historyChange + ", userModifiedId=" + userModifiedId + "]";
  }

}
