$(document).ready(function () {
//    var rowCountTopicChild = 0;
//    var idDatePickerStart = "";
//    var step = 0;
//    $("#page-wrapper").on('click','#addMilestone',function(){
////    $("#addMilestone").click(function () {
//    	var add = 0;
//        for (var i = 0; i < $(".milestone").length; i++) {
//        	add = $($($(".milestone")[$(".milestone").length - 1]).parent().next().next().next().children().children().children()).attr("id");
//		}
//        if (add != null) {
//		    add = add.substring(add.length-1);
//		    var countIdMile = parseInt(add, 10);
//        }
//        countIdMile += 1;
//        var rowCount = $('#table-milestone tr').length;
//        rowCount++;
//        var rowCountChild = 0;
//        rowCountChild++;
//
//        step = countIdMile;
//        
//        $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '"><td id="mile-id-' + 0 + '" value="' + 0 + '"><div class="milestone"><i class="fa fa-trash" id="id-remove-giangnq4"></i></div></td><td colspan="2" class="month-giangnq4">Thg2-18</td><td><div class="form-group"><select class="form-control" name="#"><option>10</option><option>20</option><option>30</option><option>40</option></select></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerStartDate' + step + '" /></div></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerEndDate' + step + '" /></div></td></tr>');
//
//        idDatePickerStart = $("tbody#tbody-giangnq4 tr td.datePicker-giangnq4").children().children().is('#datepickerStartDate' + step);
//
//        if (idDatePickerStart == true) {
//            $('#datepickerStartDate' + step).datepicker({
//                uiLibrary: 'bootstrap'
//            });
//            $('#datepickerEndDate' + step).datepicker({
//                uiLibrary: 'bootstrap'
//            });
//        }
//        
//        $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '-' + rowCount + '" value="0"><td></td><td class="td-plus"><i class="fa fa-plus-circle" id="addTopic"></i></td><td class="td-topic-giangq4">Topic</td><td class="td-topic-giangq4">Max Score</td><td class="td-topic-giangq4">Passing Score</td><td class="td-topic-giangq4">Weighted Number</td></tr>');
//
////        $("select.giangnq4IdMileClass")
//        
//        $("tbody#tbody-giangnq4").append('<tr class = "topic' + rowCount + '-' + rowCount + '"  id ="' + rowCount + '-' + rowCount + '-' + rowCountTopicChild + '"><td></td><td><i class="fa fa-trash" id="deleteTopic"></i></div></td><td><div class="form-group"><select class="form-control giangnq4IdMileClass' + rowCount + '" id="giangnq4IdMileId' + rowCount + '"></select></div></td><td><div class="form-group"><select class="form-control maxScore"></select></div></td><td><div class="form-group"><select class="form-control passingScore"></select></div></td><td><div class="form-group"><select class="form-control weightedNumber"></select></div></td></tr>');
//        
//        $("select.form-control.maxScore option").remove();
//        
//        $('select.form-control.maxScore').append('<option value="10">10</option>');
//        $('select.form-control.maxScore').append('<option value="20">20</option>');
//        
//        $("select.form-control.passingScore option").remove();
//        
//        $('select.form-control.passingScore').append('<option value="6">6</option>');
//        $('select.form-control.passingScore').append('<option value="7">7</option>');
//        
//        $("select.form-control.weightedNumber option").remove();
//        
//        $('select.form-control.weightedNumber').append('<option value="8">8</option>');
//        $('select.form-control.weightedNumber').append('<option value="9">9</option>');
//        
//        // giangnq4 20190124 start
//        var listTeam = $("#listTopic").val();
//        listTeam = listTeam.replace('[','').split(',');
//        var myArray = [];
//        for (let j = 0; j < listTeam.length; j++) {
//        		var divideList = listTeam[j].replace(']','').split('=')[1];
//        		myArray.push(divideList);
//		}
//        $('select.form-control.giangnq4IdMileClass'+rowCount+' option').remove();
//        for (let i = 0; i < myArray.length-1; i++) {
//        	for (let k = i+1; k < myArray.length; k++) {
//        		$('select#giangnq4IdMileId'+rowCount).append('<option value="'+myArray[i]+'">'+myArray[k]+'</option>');
//        		i = k;
//        		break;
//        	}
//		}
//        // giangnq4 20190124 end
//    });
//
//    $("#page-wrapper").on('click','.milestone',function(){
//    	
//    	$.get({
//    		url: "HN_FR_JAVA_18_09_AdminBoard_G3/panel/changePageSize/"+pageSize,
//    		success : function(responseText){
//    			$("#page-wrapper").html(responseText)
//    		},
//    		error: function(xhr, ajaxOptions, thrownError){
//   			 alert(thrownError);
//   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
//    		}
//    	});
//    	
//        var id = $($(this).parent().parent()).attr("id");
//        var classTopic = $($(this).parent().parent().next()).attr("id");
//        id = parseInt(id, 10);
//        $('tr#' + id).remove();
//        $('tr#' + id + '-'+id).remove();
//        $('tr.topic'+classTopic).remove();
//    });
//
//    $('#page-wrapper').on('click', 'i#deleteTopic', function () {
//        var strClass = $($(this).parent().parent()).remove();
//    });
//    // click button add Topic
//    $('#page-wrapper').on('click', '#addTopic', function () {
//        var idTopicGiangNQ4 = $($(this).parent().parent().prev()).attr("id");
//        var lengthTemp = $("select.giangnq4IdMileClass"+idTopicGiangNQ4).length;
//        
//        var idTopicNext = $($(this).parent().parent()).attr("id");
//        $('<tr class = "topic' + idTopicNext + '" id ="' + idTopicNext + '-' + lengthTemp + '"><td></td><td><i class="fa fa-trash" id="deleteTopic"></i></td><td><div class="form-group"><select class="form-control giangnq4IdMileClass' + idTopicGiangNQ4 + '" id="giangnq4IdMileId' + lengthTemp + '"></select></div></td><td><div class="form-group"><select class="form-control maxScore"></select></div></td><td><div class="form-group"><select class="form-control passingScore"></select></div></td><td><div class="form-group"><select class="form-control weightedNumber"></select></div></td></tr>').insertAfter($(this).closest('tr'));
//        
//     // giangnq4 20190124 start
//        var listTeam = $("#listTopic").val();
//        listTeam = listTeam.replace('[','').split(',');
//        var myArray = [];
//        for (let j = 0; j < listTeam.length; j++) {
//        		var divideList = listTeam[j].replace(']','').split('=')[1];
//        		myArray.push(divideList);
//		}
////        $('select.form-control.giangnq4IdMileClass'+idTopicGiangNQ4+' option').remove();
//        for (let i = 0; i < myArray.length-1; i++) {
//        	for (let k = i+1; k < myArray.length; k++) {
//        		$('select.giangnq4IdMileClass'+idTopicGiangNQ4+'#giangnq4IdMileId'+lengthTemp).append('<option value="'+myArray[i]+'">'+myArray[k]+'</option>');
//        		i = k;
//        		break;
//        	}
//		}
//        
//        $("select.form-control.maxScore option").remove();
//        
//        $('select.form-control.maxScore').append('<option value="10">10</option>');
//        $('select.form-control.maxScore').append('<option value="20">20</option>');
//        
//        $("select.form-control.passingScore option").remove();
//        
//        $('select.form-control.passingScore').append('<option value="6">6</option>');
//        $('select.form-control.passingScore').append('<option value="7">7</option>');
//        
//        $("select.form-control.weightedNumber option").remove();
//        
//        $('select.form-control.weightedNumber').append('<option value="8">8</option>');
//        $('select.form-control.weightedNumber').append('<option value="9">9</option>');
//        // giangnq4 20190124 end
//        
//    });
    
    $("a#traineeManagement").click(function(){
    	$("#page-wrapper1").html('')
    	var contextPath = $(this).attr("contextPath");
    	$.get({
    		url: contextPath + '/panel/trainee',
    		success : function(responseText){
    			$("#page-wrapper").html(responseText)
    		},
    		error: function(xhr, ajaxOptions, thrownError){
   			 alert(thrownError);
   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
    		}
    	});
    });
    
    $('#classManagement').click(function(){
    	var contextPath = $(this).attr("contextPath");
    	$.get({
    		url: contextPath + "/panel/classmanager",
    		success : function(responseText){
    			$("#page-wrapper").html(responseText)
    		},
    		error: function(xhr, ajaxOptions, thrownError){
    			$("#page-wrapper").html(xhr.responseText)
    		}
    	});
    });
    
    
    $("#page-wrapper").on('click','.page-number',function(){
    	var pageNumber = $(this).html();
    	var contextPath = $(this).attr("contextPath");
    	var pageSize = $("select#page-size-option-select-id").val();
    	$(this).attr("selected",true);
    	$.get({
    		url: contextPath + "/panel/searchAndPagingTrainee/"+pageNumber+"/"+pageSize,
    		success : function(responseText){
    			$("#page-wrapper").html(responseText)
    		},
    		error: function(xhr, ajaxOptions, thrownError){
   			 alert(thrownError);
   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
    		}
    	});
    })
    
    $("#page-wrapper").on('change','select#page-option-select-id',function(){
    	var pageNumber = $(this).val();
    	var contextPath = $(this).attr("contextPath");
    	var pageSize = $("select#page-size-option-select-id").val();
    	$.get({
    		url: contextPath + "/panel/searchAndPagingTrainee/"+pageNumber+"/"+pageSize,
    		success : function(responseText){
    			$("#page-wrapper").html(responseText)
    		},
    		error: function(xhr, ajaxOptions, thrownError){
   			 alert(thrownError);
   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
    		}
    	});
    })
    
    $("#page-wrapper").on('change','select#page-size-option-select-id',function(){
    	var pageSize = $(this).val();
    	var contextPath = $(this).attr("contextPath");
    	$("select#page-size-option-select-id option").attr("selected",true);
    	$.get({
    		url: contextPath + "/panel/changePageSize/"+pageSize,
    		success : function(responseText){
    			$("#page-wrapper").html(responseText)
    		},
    		error: function(xhr, ajaxOptions, thrownError){
   			 alert(thrownError);
   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
    		}
    	});
    })
    
    $("#page-wrapper").on('click','#btn-search',function(){
    	
        var token = $("button#btn-search").val();
        var header = "X-CSRF-TOKEN";
        $(document).ajaxSend(function(e, xhr, options) {
            xhr.setRequestHeader(header, token);
        });
    	
		var contextPath = $(this).attr("contextPath");
        var emplId = $("#emplId").val();
        var dob = $("#dob").val();
        var account = $("#account").val();
        var phone = $("#phone").val();
        var name = $("#name").val();
        var email = $("#email").val();
        
        var traineeJson = JSON.stringify({
            "traineeProfileId" : emplId,
            "dob" : dob,
            "account" : account,
            "phone" : phone,
            "fullName" : name,
            "email" : email,
        });
//        alert(traineeJson)
        var settings = {
            "crossDomain": true,
            "url": contextPath + "/panel/searchAndPagingTrainee",
            "method": "POST",
            "headers": {
              "Content-Type": "application/json",
            },
            "data": traineeJson
        };
        $.ajax(settings).done(function (responseText) {
        	$("#page-wrapper").html(responseText)
        }).fail((response)=>{
        	alert("error"+response);
       });
    });
    
    $("#page-wrapper").on('click','input#checkAllIdTrainee',function(){
    	if($("input#checkAllIdTrainee").is(':checked')){
    		$("input.rowChecked").prop( "checked", true );
    	}else{
    		$("input.rowChecked").prop( "checked", false );	
    	}
    });
    
    
    $("#page-wrapper").on('click','button#updateTrainee',function loadData() {
    	var arrIdTrainee = $(".rowChecked:checked");
    	if (arrIdTrainee.length == 1) {
	    	var idTrainee = $(".rowChecked:checked").val();
	    	var contextPath = $(this).attr("contextPath");
	    	var list = [];
	    	$.get({
			url: contextPath + "/panel/updateTrainee1/"+idTrainee,
			success : function(responseText){
				$("#page-wrapper").html(responseText)
			},
			error: function(xhr, ajaxOptions, thrownError){
				 alert(thrownError);
				 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
			}
	    	});
    	}else{
    		alert(">1")
    	}
    });
    
    
    $("#page-wrapper").on('click','a.traineeIdTbl',function(){
    	
    	var traineeIdTbl = $(this).html();
    	var contextPath = $(this).attr("contextPath");
    	$.get({
    		url: contextPath + "/panel/viewTrainee/"+traineeIdTbl,
    		success : function(responseText){
    			$("#page-wrapper").html(responseText)
    		},
    		error: function(xhr, ajaxOptions, thrownError){
   			 alert(thrownError);
   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page!</h3>");
    		}
    	});
    })
});