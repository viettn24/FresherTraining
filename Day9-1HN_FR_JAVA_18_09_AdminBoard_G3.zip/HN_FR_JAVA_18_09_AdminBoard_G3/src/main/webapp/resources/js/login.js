$(document).ready(function () {
    $('#login-form').submit(function () { 
        
        var usernameValue = $('#username').val();
        var passwordValue = $('#password').val();
        var countInputSuccess = 0;

        if (passwordValue == "") {
            $('.errorMessage').html('Password must not empty!')
        }

        if (usernameValue == "") {
            $('.errorMessage').html('Username must not empty!')
        }

        if (usernameValue != "") {
            countInputSuccess++;
        }

        if(passwordValue != ""){
            countInputSuccess++;
        }

        if(countInputSuccess == 2){
            return true;
        }
        
        return false;
        
    });
});