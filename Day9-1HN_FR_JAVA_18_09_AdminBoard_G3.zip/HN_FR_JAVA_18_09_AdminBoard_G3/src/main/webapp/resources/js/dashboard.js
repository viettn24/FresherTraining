var list = [];
var listByStatusPlanning = [];
var listByStatusPlanned = [];
var listByStatusInProcess = [];

var listPlanningFinal = [];
var listPlanedFinal = [];
var listInProcessFinal = [];
$(document).ready(function () {


    (function loadData() {
        var contextPath = "/HN_FR_JAVA1809_AdminBoard_G1";
        $.ajax({
            url: "/HN_FR_JAVA_18_09_AdminBoard_G3/panel/getAllClassBatch"
        }).then(function (data) {
            list = data;

            listByStatusPlanning = listByStatusName(1, list)
            listByStatusPlanned = listByStatusName(2, list)
            listByStatusInProcess = listByStatusName(3, list)
            $("#planning-tbody").mirandajs(listByStatusPlanning);
            $("#planed-tbody").mirandajs(listByStatusPlanned);
            $("#inProcess-tbody").mirandajs(listByStatusInProcess);

            setListLocationName = getLocationName(list);
            $("#location").mirandajs(setListLocationName);

            setListStatusName = getStatus(list);
            $("#status").mirandajs(setListStatusName);


            // var locationName = "All";
            // listByLocation = listByLocationName(locationName, list);

            // var status = "All";
            // listByStatus = listByStatusName(status, listByLocation)

            listPlanningFinal = listByStatusPlanning;
            listPlanedFinal = listByStatusPlanned;
            listInProcessFinal = listByStatusInProcess;

        });

    })();







    $('#location').change(function () {
        

        var locationValue = $(this).val();
        var statusValue = $('#status').val();

        listByLocation = listByLocationName(locationValue, list);
        listByStatusPlanning = listByStatusName(1, listByLocation)
        listByStatusPlanned = listByStatusName(2, listByLocation)
        listByStatusInProcess = listByStatusName(3, listByLocation)

        listPlanningFinal = listByStatusPlanning;
        listPlanedFinal = listByStatusPlanned;
        listInProcessFinal = listByStatusInProcess;

        if (statusValue == "1") {
            loadByLocationReal('.planning-td', '#planning-tbody tr', 'planning-td', '#planning-tbody', 'planningTraineeNumber', listByStatusPlanning)
            locationStatusChangeView('#table-planning1', '#table-planning2', '#table-planning3')
        }

        if (statusValue == "2") {
            loadByLocationReal('.planed-td', '#planed-tbody tr', 'planed-td', '#planed-tbody', 'planedTraineeNumber', listByStatusPlanned)
            locationStatusChangeView('#table-planning2', '#table-planning1', '#table-planning3')
        }


        if (statusValue == "3") {
            loadByLocationReal('.inProcess-td', '#inProcess-tbody tr', 'inProcess-td', '#inProcess-tbody', 'inprogressTraineeNumber', listByStatusInProcess)
            locationStatusChangeView('#table-planning3', '#table-planning1', '#table-planning2')
            // $('.inProcess-td').remove();
            // $('#inProcess-tbody tr').remove();
            // $('#inProcess-tbody').append("<tr> <td class='inProcess-td'>[[className]]</td> <td class='inProcess-td'>[[inprogressTraineeNumber]]</td> </tr>")

            // $("#inProcess-tbody").mirandajs(listByStatusInProcess);
        }

        if (statusValue == "All") {
            loadByLocationReal('.planning-td', '#planning-tbody tr', 'planning-td', '#planning-tbody', 'planningTraineeNumber', listByStatusPlanning)
            loadByLocationReal('.planed-td', '#planed-tbody tr', 'planed-td', '#planed-tbody', 'planedTraineeNumber', listByStatusPlanned)
            loadByLocationReal('.inProcess-td', '#inProcess-tbody tr', 'inProcess-td', '#inProcess-tbody', 'inprogressTraineeNumber', listByStatusInProcess)
        }
        google.charts.setOnLoadCallback(drawChart);

    });


    $('#status').change(function () {
       
        
        var statusValue = $(this).val();
        var locationValue = $('#location').val();


        listByStatusPlanning = listByStatusName(1, list)
        listByStatusPlanned = listByStatusName(2, list)
        listByStatusInProcess = listByStatusName(3, list)

        listByLocationOfPlanning = listByLocationName(locationValue, listByStatusPlanning);
        listByLocationOfPlanned = listByLocationName(locationValue, listByStatusPlanned);
        listByLocationOfInProcess = listByLocationName(locationValue, listByStatusInProcess);


        listPlanningFinal = listByLocationOfPlanning;
        listPlanedFinal = listByLocationOfPlanned;
        listInProcessFinal = listByLocationOfInProcess;
        
        

        if (statusValue == "1") {
            loadByLocationReal('.planning-td', '#planning-tbody tr', 'planning-td', '#planning-tbody', 'planningTraineeNumber', listByLocationOfPlanning)
            locationStatusChangeView('#table-planning1', '#table-planning2', '#table-planning3')
            locationStatusChangeView('#piechart1', '#piechart2', '#piechart3')
        }

        if (statusValue == "2") {
            loadByLocationReal('.planed-td', '#planed-tbody tr', 'planed-td', '#planed-tbody', 'planedTraineeNumber', listByLocationOfPlanned)
            locationStatusChangeView('#table-planning2', '#table-planning1', '#table-planning3')
            locationStatusChangeView('#piechart2', '#piechart3', '#piechart1')
        }


        if (statusValue == "3") {
            loadByLocationReal('.inProcess-td', '#inProcess-tbody tr', 'inProcess-td', '#inProcess-tbody', 'inprogressTraineeNumber', listByLocationOfInProcess)
            locationStatusChangeView('#table-planning3', '#table-planning2', '#table-planning1')
            locationStatusChangeView('#piechart3', '#piechart2', '#piechart1')
        }

        if (statusValue == "All") {
            loadByLocationReal('.planning-td', '#planning-tbody tr', 'planning-td', '#planning-tbody', 'planningTraineeNumber', listByLocationOfPlanning)
            loadByLocationReal('.planed-td', '#planed-tbody tr', 'planed-td', '#planed-tbody', 'planedTraineeNumber', listByLocationOfPlanned)
            loadByLocationReal('.inProcess-td', '#inProcess-tbody tr', 'inProcess-td', '#inProcess-tbody', 'inprogressTraineeNumber', listByLocationOfInProcess)

            locationStatusChangeViewAll('#piechart1', '#piechart2', '#piechart3')
            locationStatusChangeViewAll('#table-planning1', '#table-planning2', '#table-planning3')

        }
        google.charts.setOnLoadCallback(drawChart);

    });



    $('#type-dashboard').change(function () {
        if ($(this).val() == 1) {
            $('.analytic-table').removeClass('we-are-hidden');
            $('.analytic-table').addClass('we-are-not-hidden');
            $('.analytic-chart').addClass('we-are-hidden');
            $('.analytic-chart').removeClass('we-are-not-hidden');
        }
        if ($(this).val() == 2) {
            $('.analytic-table').addClass('we-are-hidden');
            $('.analytic-table').removeClass('we-are-not-hidden');
            $('.analytic-chart').removeClass('we-are-hidden');
            $('.analytic-chart').addClass('we-are-not-hidden');
        }
    });





    // Load google charts
    google.charts.load('current', {
        'packages': ['corechart']
    });
    google.charts.setOnLoadCallback(drawChart);



    // Draw the chart and set the chart values
    function drawChart() {

        var data1 = new google.visualization.DataTable();
        var data2 = new google.visualization.DataTable();
        var data3 = new google.visualization.DataTable();

        data1.addColumn('string', 'Class Name');
        data1.addColumn('number', 'Plan of enrolment');
        $.each(listPlanningFinal, function (indexInArray, valueOfElement) {
            data1.addRows(
                [
                    [valueOfElement.className, valueOfElement.planningTraineeNumber],
                ]
            );
        });


        data2.addColumn('string', 'Class Name');
        data2.addColumn('number', 'Plan of enrolment');
        $.each(listPlanedFinal, function (indexInArray, valueOfElement) {
            data2.addRows(
                [
                    [valueOfElement.className, valueOfElement.planningTraineeNumber],
                ]
            );
        });

        data3.addColumn('string', 'Class Name');
        data3.addColumn('number', 'Plan of enrolment');
        $.each(listInProcessFinal, function (indexInArray, valueOfElement) {
            data3.addRows(
                [
                    [valueOfElement.className, valueOfElement.planningTraineeNumber],
                ]
            );
        });




        // Optional; add a title and set the width and height of the chart
        var options1 = {
            'title': 'Planning',
            'width': document.getElementsByClassName('col-md-4')[0].offsetWidth,
            'height': 400
        };
        var options2 = {
            'title': 'Planned',
            'width': document.getElementsByClassName('col-md-4')[0].offsetWidth,
            'height': 400
        };
        var options3 = {
            'title': 'In Process',
            'width': document.getElementsByClassName('col-md-4')[0].offsetWidth,
            'height': 400
        };

        // Display the chart inside the <div> element with id="piechart"
        var chart1 = new google.visualization.PieChart(document.getElementById('piechart1'));
        var chart2 = new google.visualization.PieChart(document.getElementById('piechart2'));
        var chart3 = new google.visualization.PieChart(document.getElementById('piechart3'));

        chart1.draw(data1, options1);
        chart2.draw(data2, options2);
        chart3.draw(data3, options3);
    }


});

function locationStatusChangeViewAll(idShow1, idShow2, idShow3) { 
    $(idShow1).removeClass('chart-hidden');
    $(idShow2).removeClass('chart-hidden');
    $(idShow3).removeClass('chart-hidden');
}

function locationStatusChangeView(idShow, idHidden1, idHidden2) { 
    $(idShow).removeClass('chart-hidden');
    $(idHidden1).addClass('chart-hidden');
    $(idHidden2).addClass('chart-hidden');
}




function loadByLocationReal(td, tbody_tr, td2, tbody, number, listByStatusPlanning) {
    $(td).remove();
    $(tbody_tr).remove();
    var strAppend = "<tr> <td class='" + td2 + "'>[[className]]</td> <td class='" + td2 + "'>[[" + number + "]]</td> </tr>";
    $(tbody).append(strAppend);

    $(tbody).mirandajs(listByStatusPlanning);

}



function listByStatusName(status, listByLocation) {
    if (status == "All") {
        return listByLocation;
    }
    listByStatus = [];
    $.each(listByLocation, function (indexInArray, valueOfElement) {
        if (valueOfElement.status == status) {
            listByStatus.push(valueOfElement);
        }
    });

    return listByStatus;
}


function listByLocationName(locationName, list) {
    if (locationName == "All") {
        return list;
    }
    var listByLocation = [];
    $.each(list, function (indexInArray, valueOfElement) {
        if (valueOfElement.locationId.locationName == locationName) {
            listByLocation.push(valueOfElement);
        }
    });
    return listByLocation;
}



function getLocationName(list) {
    arrayListLocation = [];
    $.each(list, function (indexInArray, valueOfElement) {
        arrayListLocation.push(valueOfElement.locationId.locationName);
        uniqueLocationName = [...new Set(arrayListLocation)];
    });

    var setListLocationName = [];
    var singleObj = {};
    singleObj['locationName'] = "All";
    setListLocationName.push(singleObj);

    uniqueLocationName.forEach(function (entry) {
        var singleObj = {};
        singleObj['locationName'] = entry;
        setListLocationName.push(singleObj);
    });

    return setListLocationName;

}


function getStatus(list) {
    arrayListStatus = [];
    $.each(list, function (indexInArray, valueOfElement) {
        arrayListStatus.push(valueOfElement.status);
        uniqueStatusName = [...new Set(arrayListStatus)];
    });

    var setListStatusName = [];
    var singleObj = {};
    singleObj['statusName'] = "All";
    setListStatusName.push(singleObj);

    uniqueStatusName.forEach(function (entry) {
        var singleObj = {};
        singleObj['statusName'] = entry;
        setListStatusName.push(singleObj);
    });

    return setListStatusName;

}
