$(document).ready(function () {
    $("#btn-attendance").click(function (e) {
        e.preventDefault();
        $("#tbl-attendance").toggle();
    });

    $("#btn-reward").click(function (e) {
        e.preventDefault();
        $("#tbl-reward").toggle();
    });

    $("#btn-gpa").click(function (e) {
        e.preventDefault();
        $("#tbl-gpa").toggle();
    });

    $("#btn-commitment").click(function (e) {
        e.preventDefault();
        $("#tbl-commitment").toggle();
    });

    $("#btn-allowance").click(function (e) {
        e.preventDefault();
        $("#tbl-allowance").toggle();
    });

    $("#btn-allocation").click(function (e) {
        e.preventDefault();
        $("#tbl-allocation").toggle();
    });

    $("#btn-milestone-config").click(function (e) {
        e.preventDefault();
        $("#tbl-milestone-config").toggle();
    });
});