$(document).ready(function () {
	var idTraineeHidden;
	var list = [];
	var traineeProfile = [];
	 
	// //////////DROP DOWN - SELECT BUTTON EVENT///////////////
	
	$('#page-wrapper').on('click','.university-input',function () {
        var universityElement = $(this).attr('universityName')
        $('#university-value').html(universityElement);
        $('#university-value').attr({
        	"universityId" : $("input[name='university-input']:checked").val()
        });
    });

    $('#page-wrapper').on('click','.faculty-input',function () {
        var facultyElement = $(this).attr('facultyName')
        $('.faculty-value').html(facultyElement);
        $('#faculty-value').attr({
        	"facultyId" : $("input[name='faculty-input']:checked").val()
        })
        
    });

    $('#page-wrapper').on('click','.allowanceGroup-input',function () {
        var allowanceGroupElement = $(this).attr('allowanceGroupName')
        $('.allowanceGroup-value').html(allowanceGroupElement);
        $('#allowanceGroup-value').attr({
        	"allowanceGroupId" : $("input[name='allowanceGroup-input']:checked").val()
        })
    });

    $('#page-wrapper').on('click','.university-input-other',function () {
        $('.university-input-textbox').removeClass('university-input-other-hidden');

    });

    $('#page-wrapper').on('click','.university-input',function () {
        $('.university-input-textbox').addClass('university-input-other-hidden');

    });

    $('#page-wrapper').on('click','.allowanceGroup-input-other',function () {
        $('.allowanceGroup-input-textbox').removeClass('allowanceGroup-input-other-hidden');

    });

    $('#page-wrapper').on('click','.allowanceGroup-input',function () {
        $('.allowanceGroup-input-textbox').addClass('allowanceGroup-input-other-hidden');

    });

    $('#page-wrapper').on('click','.faculty-input-other',function () {
        $('.faculty-input-textbox').removeClass('faculty-input-other-hidden');

    });

    $('#page-wrapper').on('click','.faculty-input',function () {
        $('.faculty-input-textbox').addClass('faculty-input-other-hidden');

    });
    
    //////////END DROP DOWN - SELECT BUTTON EVENT///////////////
    
    
    
    //////////AJAX LOAD UPDATE TRAINEE PAGE////////////
    
    $('#page-wrapper').on('click','.salary-input',function () {
        var salaryElement = $(this).val()
        if(salaryElement == 'no'){
        	$('#allowanceGroupButton').addClass('allowanceGroupDisable');
        	$('#tdAllowanceGroup').addClass('tdAllowanceGroup');
        	$('.allowanceGroup-value').html('');
        }
        if(salaryElement == 'yes'){
        	$('#allowanceGroupButton').removeClass('allowanceGroupDisable');
        	$('#tdAllowanceGroup').removeClass('tdAllowanceGroup');
        }
        
    });


    (function loadData() {
        $.ajax({
            url: "/HN_FR_JAVA_18_09_AdminBoard_G3/panel/updateTrainee/"+idTraineeHidden
        }).then(function (data) {
            list.push(data);
            traineeProfile.push(data.traineeProfile);
        });
    })();


    $('#page-wrapper').on('click','#updateTraineeButton',function () {
    	idTraineeHidden = $("#idTraineeHidden").val();
    	
    	
    	var contextPath = $(this).attr("contextPath");
        var token = $("button#updateResultButton").val();
        var header = "X-CSRF-TOKEN";
        $(document).ajaxSend(function(e, xhr, options) {
            xhr.setRequestHeader(header, token);
        });
        
        var traineeProfileId = $('#traineeProfileId').val();
        
    	var universityId = $('#university-value').attr('universityId');
    	var universityName = $('#university-value').html();
    	var facultyId = $('#faculty-value').attr('facultyId');
    	var facultyName = $('#faculty-value').html();
    	var allowanceGroupId = $('#allowanceGroup-value').attr('allowanceGroupId');
    	var allowanceGroupName = $('#allowanceGroup-value').html();
    	
    	var fullName = $('#fullName').val();
    	var gender = $("input[name='gender']:checked").val();
    	var email = $('#email').val();
    	var phone = $('#phone').val();
    	var account = $('#account').val();
    	var tpBank = $('#tpBank').val();
    	var salaryPaid = $("input[name='salary-paid']:checked").val();
    	var type = $('#type').val();
    	var userId = $('#userId').val();
    	var dob = new Date($('#datepicker-dob').val());
    	var listHistory =[];
    	var dateNow = new Date;
    	
    	var singleUser = {
    			"id" : userId
    	}
    	
    	var singleHistory = {
    			"historyChange" : dateNow.getTime(),
    			"userModifiedId" : singleUser
    	}
    	listHistory.push(singleHistory);
    	
    	var salaryElement = $("input[name='salary-paid']:checked").val();
    	var otherUniversity = $("input[name='university-input']:checked").val();
    	var otherFaculty = $("input[name='faculty-input']:checked").val();
    	
    	if(otherUniversity == 'other'){
    		universityId = 0;
    		universityName = $('#other-university').val();
    	}
    	
    	if(otherFaculty == 'other'){
    		facultyId = 0;
        	facultyName = $('#other-faculty').val();
    	}
        
        var University = {
        		"universityId" : universityId,
        		"universityName" : universityName
        }
        
        var Faculty = {
        		"facultyId" : facultyId,
        		"facultyName" : facultyName
        }
    
        var traineeProfiles = {
       		"traineeProfileId" : traineeProfileId,
       		"universityId" : University,
       		"facultyId" : Faculty,
       		"fullName" : fullName,
       		"gender" : gender,
       		"email" : email,
       		"phone" : phone,
       		"account" : account,
       		"tpBank" : tpBank,
       		"type" : type,
       		"dob" : dob,
        		
        }
        
        var AllowanceGroup = {
        		"allowanceGroupId" : allowanceGroupId,
        		"allowanceGroupName" : allowanceGroupName
        }
        
    	if(salaryElement == 'no' || allowanceGroupId == ''){
    		AllowanceGroup = null
    	}
          
		var trainee = JSON.stringify({
			"traineeId" : idTraineeHidden,
			"salaryPaid" : salaryPaid,
			"allowanceGroupId" : AllowanceGroup,
			"traineeProfiles" : traineeProfiles,
			"listHistory" : listHistory
		});
        var settings = {
            "crossDomain": true,
            "url": contextPath + "/panel/updateTraineeProfile",
            "method": "POST",
            "headers": {
              "Content-Type": "application/json",
            },
            "data": trainee
        };
        
        alert(salaryPaid)
        
        $.ajax(settings).done(function (responseText) {
        	$("#page-wrapper").html(responseText)
        	alert('Success!');
        }).fail((response)=>{
        	alert("error"+response);
       });
    });

    

});

