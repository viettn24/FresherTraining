$(document).ready(function () {
	var idTraineeHidden = $("#idTraineeHidden").val();
	var list = [];
	var traineeProfile = [];
	var listMilestone = [];
	var listMilestoneTopic = [];
    	(function loadData() {
	        $.ajax({
	            url: "/HN_FR_JAVA_18_09_AdminBoard_G3/panel/viewTrainee1/"+idTraineeHidden
	        }).then(function (data) {
	        	list.push(data);
	        	traineeProfile.push(data.traineeProfile);
	        	listMilestone.push(data.milestones);
	            updateMilestone();
	        });
        })();
    	
    function updateMilestone(){
    	var rowCount = 0;
    	var step = 0;
        var rowCountChild = 0;
        var rowCountTopicChild = 0;
        // get date
        
        for (var i = 0; i < listMilestone[0].length; i++) {
        	rowCount = i;
        	step = i;
        	rowCountChild = i;
        	rowCountTopicChild = i;
        	var milestoneName = listMilestone[0][i]["milestoneName"];
        	var salaryPaid = listMilestone[0][i]["salaryPaid"];
	        // get date
	        var startDate = listMilestone[0][i]["startDate"];
	        var outputStartDate = convertDate(startDate);
	        $('#datepickerStartDate'+rowCount).val(outputStartDate);
	        
	        var endDate = listMilestone[0][i]["endDate"];
	        var outputEndDate = convertDate(endDate);
	        
	        $('#datepickerEndDate'+rowCount).val(outputEndDate);
        	
 	       $("tbody#tbody-giangnq4").append('<tr><td></td><td colspan="2">'+milestoneName+'</td><td>'+salaryPaid+'</td><td>'+outputStartDate+'</td><td>'+outputEndDate+'</td></tr>');

	        $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '-' + rowCountChild + '"><td></td><td class="td-plus"><i id="addTopic"></i></td><td class="td-topic-giangq4">Topic</td><td class="td-topic-giangq4">Max Score</td><td class="td-topic-giangq4">Passing Score</td><td class="td-topic-giangq4">Weighted Number</td></tr>');
	        for (var j = 0; j < listMilestone[0][i]["milestoneTopics"].length; j++) {
	        	var max_score = listMilestone[0][i]["milestoneTopics"][j]["max_score"];
	        	var passingScore = listMilestone[0][i]["milestoneTopics"][j]["passingScore"];
	        	var weightedNumber = listMilestone[0][i]["milestoneTopics"][j]["weightedNumber"];
	        	var topic = listMilestone[0][i]["milestoneTopics"][j]["topic"];
	        	var topicName = topic["topicName"];
	        	$("tbody#tbody-giangnq4").append('<tr class = "topic' + rowCount + '-' + rowCountChild + '"  id ="' + rowCount + '-' + rowCountChild + '-' + rowCountTopicChild + '"><td></td><td><i id="deleteTopic"></i></div></td><td>'+topicName+'</td><td>'+max_score+'</td><td>'+passingScore+'</td><td>'+weightedNumber+'</td></tr>');
	        }
        }
    }
    
    function convertDate(dateTemp){
        var d = new Date(dateTemp);
        var month = d.getMonth()+1;
        var day = d.getDate();
        var output =((''+month).length<2 ? '0' : '') + month +  '/' + ((''+day).length<2 ? '0' : '') + day + '/' + d.getFullYear();
        return output;
    }
    // submit trainee
});
