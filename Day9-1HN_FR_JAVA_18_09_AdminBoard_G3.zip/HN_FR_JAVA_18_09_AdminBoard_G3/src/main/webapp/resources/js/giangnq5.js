$(document).ready(function () {
    var listMaxScores = [];
    for (var i = 0; i <= 100; i+=5) {
    	listMaxScores.push(i);
	}
	
	var idTraineeHidden = $("#idTraineeHidden").val();
    var listTopic = [];
    var tien = "";
    var list = [];
    var traineeProfile = [];
    var listMilestone = [];
    var listMilestoneTopic = [];
    
    var rowCountTopicChild = 0;
    var idDatePickerStart = "";
    var step = 0;
    // addMilestone
    $("#page-wrapper").on('click','#addMilestone',function(){
    	var add = 0;
    	var countIdMile = 0;
        for (var i = 0; i < $(".milestone").length; i++) {
        	add = $($($(".milestone")[$(".milestone").length - 1]).parent().next().next().next().children().children().children()).attr("id");
		}
        if (add != 0) {
		    add = add.substring(add.length-1);
		    countIdMile = parseInt(add, 10);
        }else{
        }
        countIdMile += 1;
        var rowCount = $('#table-milestone tr').length;
        rowCount++;
        var rowCountChild = 0;
        rowCountChild++;

        step = countIdMile;
        
        $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '"><td id="mile-id-' + 0 + '" value="' + 0 + '"><div class="milestone"><i class="fa fa-trash" id="id-remove-giangnq4"></i></div></td><td colspan="2" class="month-giangnq4">Thg2-18</td><td><div class="form-group"><select class="form-control salaryPaid"><option value="1" selected="selected">YES</option><option value="0">NO</option></select></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerStartDate' + step + '" /></div></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerEndDate' + step + '" /></div></td></tr>');

        idDatePickerStart = $("tbody#tbody-giangnq4 tr td.datePicker-giangnq4").children().children().is('#datepickerStartDate' + step);

        if (idDatePickerStart == true) {
            $('#datepickerStartDate' + step).datepicker({
                uiLibrary: 'bootstrap'
            });
            $('#datepickerEndDate' + step).datepicker({
                uiLibrary: 'bootstrap'
            });
        }
        
        $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '-' + rowCount + '" value="0"><td></td><td class="td-plus"><i class="fa fa-plus-circle" id="addTopic"></i></td><td class="td-topic-giangq4">Topic</td><td class="td-topic-giangq4">Max Score</td><td class="td-topic-giangq4">Passing Score</td><td class="td-topic-giangq4">Weighted Number</td></tr>');

        
        $("tbody#tbody-giangnq4").append('<tr class = "topic' + rowCount + '-' + rowCount + '"  id ="' + rowCount + '-' + rowCount + '-' + rowCountTopicChild + '"><td></td><td><i class="fa fa-trash" id="deleteTopic"></i></div></td><td><div class="form-group"><select class="form-control giangnq4IdMileClass' + rowCount + '" id="giangnq4IdMileId' + rowCount + '"></select></div></td><td><div class="form-group"><select class="form-control maxScore' + rowCount + '" id="giangnq4IdMaxScore' + rowCount + '"></select></div></td><td><div class="form-group"><select class="form-control passingScore' + rowCount + '" id="giangnq4IdPassingScore' + rowCount + '"></select></div></td><td><div class="form-group"><select class="form-control weightedNumber' + rowCount + '" id="giangnq4IdWeightedNumberId' + rowCount + '"></select></div></td></tr>');
        $("select.form-control.maxScore option").remove();
        for (var i = 0; i <= 100; i+=5) {
        	$('select.form-control.maxScore'+rowCount).append('<option value="'+i+'">'+i+'</option>');
		}
        
        $("select.form-control.passingScore option").remove();
        for (var i = 0; i <= 100; i+=5) {
        	$('select.form-control.passingScore'+rowCount).append('<option value="'+i+'">'+i+'</option>');
		}
        
        $("select.form-control.weightedNumber option").remove();
        for (var i = 0; i <= 100; i+=5) {
        	$('select.form-control.weightedNumber'+rowCount).append('<option value="'+i+'">'+i+'</option>');
		}
        // giangnq4 20190124 start
        var listTeam = $("#listTopic").val();
        listTeam = listTeam.replace('[','').split(',');
        var myArray = [];
        for (let j = 0; j < listTeam.length; j++) {
        		var divideList = listTeam[j].replace(']','').split('=')[1];
        		myArray.push(divideList);
		}
        $('select.form-control.giangnq4IdMileClass'+rowCount+' option').remove();
        for (let i = 0; i < myArray.length-1; i++) {
        	for (let k = i+1; k < myArray.length; k++) {
        		$('select#giangnq4IdMileId'+rowCount).append('<option value="'+myArray[i]+'">'+myArray[k]+'</option>');
        		i = k;
        		break;
        	}
		}
        // giangnq4 20190124 end
    });
    
    // delete milestone giangnq4 start 20190127
    $("#page-wrapper").on('click','.milestone',function(){
    	var milestoneIdRemove =  $($(this).parent()).attr("id");
    	milestoneIdRemove = milestoneIdRemove.substring(8,milestoneIdRemove.length);
    	$.get({
    		url: "http://localhost:8080/HN_FR_JAVA_18_09_AdminBoard_G3/panel/delete/"+milestoneIdRemove,
    		success : function(responseText){
    			$("span#message").html(responseText);
    		},
    		error: function(xhr, ajaxOptions, thrownError){
   			 alert(thrownError);
   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page1!</h3>");
    		}
    	});
    	
    	var id = $($(this).parent().parent()).attr("id");
        var classTopic = $($(this).parent().parent().next()).attr("id");
        id = parseInt(id, 10);
        $('tr#' + id).remove();
        $('tr#' + id + '-'+id).remove();
        $('tr.topic'+classTopic).remove();
    });
    
    // delete milestone giangnq4 end 20190127
    $('#page-wrapper').on('click', 'i#deleteTopic', function () {
    	var milestoneTopicIdRemove = $($(this).parent().prev()).attr("id");
    	if (milestoneTopicIdRemove != undefined) {
	    	$.get({
	    		url: "http://localhost:8080/HN_FR_JAVA_18_09_AdminBoard_G3/panel/deleteTopic/"+milestoneTopicIdRemove,
	    		success : function(responseText){
	    			$("span#message").html(responseText);
	    		},
	    		error: function(xhr, ajaxOptions, thrownError){
	   			 alert(thrownError);
	   			 $("#page-wrapper").html("<h3 style = 'color: red; margin: 0 0 0 20px'>Error, Can't load page1!</h3>");
	    		}
	    	});
    	}
        var strClass = $($(this).parent().parent()).remove();
    });
    // click button add Topic
    $('#page-wrapper').on('click', '#addTopic', function () {
        var idTopicGiangNQ4 = $($(this).parent().parent().prev()).attr("id");
        var lengthTemp = $("select.giangnq4IdMileClass"+idTopicGiangNQ4).length;
        var idTopicNext = $($(this).parent().parent()).attr("id");
        $('<tr class = "topic' + idTopicNext + '" id ="' + idTopicNext + '-' + lengthTemp + '"><td></td><td><i class="fa fa-trash" id="deleteTopic"></i></td><td><div class="form-group"><select class="form-control giangnq4IdMileClass' + idTopicGiangNQ4 + '" id="giangnq4IdMileId' + lengthTemp + '"></select></div></td><td><div class="form-group"><select class="form-control maxScore' + idTopicGiangNQ4 + '"id="giangnq4IdMaxScore' + lengthTemp + '"></select></div></td><td><div class="form-group"><select class="form-control passingScore' + idTopicGiangNQ4 + '" id="giangnq4IdPassingScore' + lengthTemp + '"></select></div></td><td><div class="form-group"><select class="form-control weightedNumber' + idTopicGiangNQ4 + '" id="giangnq4IdWeightedNumberId' + lengthTemp + '"></select></div></td></tr>').insertAfter($(this).closest('tr'));
        
     // giangnq4 20190124 start
        var listTeam = $("#listTopic").val();
        listTeam = listTeam.replace('[','').split(',');
        var myArray = [];
        for (let j = 0; j < listTeam.length; j++) {
        		var divideList = listTeam[j].replace(']','').split('=')[1];
        		myArray.push(divideList);
		}
        for (let i = 0; i < myArray.length-1; i++) {
        	for (let k = i+1; k < myArray.length; k++) {
        		$('select.giangnq4IdMileClass'+idTopicGiangNQ4+'#giangnq4IdMileId'+lengthTemp).append('<option value="'+myArray[i]+'">'+myArray[k]+'</option>');
        		i = k;
        		break;
        	}
		}
        
        for (var i = 0; i <= 100; i+=5) {
        	$('select#giangnq4IdMaxScore'+lengthTemp).append('<option value="'+i+'">'+i+'</option>');
		}
        
        for (var i = 0; i <= 100; i+=5) {
        	$('select#giangnq4IdPassingScore'+lengthTemp).append('<option value="'+i+'">'+i+'</option>');
		}
        
        for (var i = 0; i <= 100; i+=5) {
        	$('select#giangnq4IdWeightedNumberId'+lengthTemp).append('<option value="'+i+'">'+i+'</option>');
		}
        // giangnq4 20190124 end
        
    });

    // load database
    (function loadData() {
        $.ajax({
            url: "/HN_FR_JAVA_18_09_AdminBoard_G3/panel/updateTraineeHehe/" + idTraineeHidden
        }).then(function (data) {

            list.push(data);
            traineeProfile.push(data.traineeProfile);
            listMilestone.push(data.milestones);
            getMilestoneInformation();
            $("#account").mirandajs(traineeProfile);
            $("#fullName").mirandajs(traineeProfile);
            $("#phone").mirandajs(traineeProfile);
            $("#tpbAccount").mirandajs(traineeProfile);
        });
    })();

    var listTeam = $("#listTopic").val();
    listTeam = listTeam.replace('[', '').split(',');
    var myArray = [];
    for (let j = 0; j < listTeam.length; j++) {
        var divideList = listTeam[j].replace(']', '').split('=')[1];
        myArray.push(divideList);
    }

    // load data use jquery
    function getMilestoneInformation() {
        var rowCount = 0;
        var step = 0;
        var rowCountChild = 0;
        var rowCountTopicChild = 0;
        var idSelect = 0;
        var idMaxScore = 0;
        var idPassingScore = 0;
        var idWeightedNumber = 0;

        // get date
        for (let i = 0; i < listMilestone[0].length; i++) {
        	
            let idMileStone = listMilestone[0][i]["milestoneId"];
            let listMilestoneTopics = listMilestone[0][i]["milestoneTopics"];
            let salaryPaid = listMilestone[0][i]["salaryPaid"];

            rowCount = i;
            step = i;
            rowCountChild = i;
            rowCountTopicChild = i;
            if (salaryPaid == 1) {
                salaryPaid = "selected";
                $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '"><td id="mile-id-' + idMileStone + '" value="' + idMileStone + '"><div class="milestone"><i class="fa fa-trash" id="id-remove-giangnq4"></i></div></td><td colspan="2" class="month-giangnq4" id="month-giangnq4-id-' + rowCount + '">Thg2-18</td><td><div class="form-group"><select class="form-control salaryPaid"><option value="1" selected="selected">YES</option><option value="0">NO</option></select></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerStartDate' + step + '" /></div></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerEndDate' + step + '" /></div></td></tr>');
            } else {
                salaryPaid = "";
                $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '"><td id="mile-id-' + idMileStone + '" value="' + idMileStone + '"><div class="milestone"><i class="fa fa-trash" id="id-remove-giangnq4"></i></div></td><td colspan="2" class="month-giangnq4" id="month-giangnq4-id-' + rowCount + '">Thg2-18</td><td><div class="form-group"><select class="form-control salaryPaid"><option value="1">YES</option><option value="0" selected="selected">NO</option></select></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerStartDate' + step + '" /></div></div></td><td class="datePicker-giangnq4"><div class="form-group"><input class="form-control" id="datepickerEndDate' + step + '" /></div></td></tr>');
            }

            idDatePickerStart = $("tbody#tbody-giangnq4 tr td.datePicker-giangnq4").children().children().is('#datepickerStartDate' + step);

            $("#month-giangnq4-id-" + rowCount).html(listMilestone[0][i]["milestoneName"]);
            if (idDatePickerStart == true) {
                $("input#datepicker").datepicker({
                    uiLibrary: 'bootstrap'
                });

                $('#datepickerStartDate' + step).datepicker({
                    uiLibrary: 'bootstrap'
                });
                $('#datepickerEndDate' + step).datepicker({
                    uiLibrary: 'bootstrap'
                });
            }
            // get date
            var milestoneTopicId = listMilestone[0][i]["milestoneId"];

            var startDate = listMilestone[0][i]["startDate"];
            var outputStartDate = convertDate(startDate);
            $('#datepickerStartDate' + rowCount).val(outputStartDate);

            var endDate = listMilestone[0][i]["endDate"];
            var outputEndDate = convertDate(endDate);

            $('#datepickerEndDate' + rowCount).val(outputEndDate);

            $("tbody#tbody-giangnq4").append('<tr id ="' + rowCount + '-' + rowCountChild + '" value="' + milestoneTopicId + '"><td></td><td class="td-plus"><i class="fa fa-plus-circle" id="addTopic"></i></td><td class="td-topic-giangq4">Topic</td><td class="td-topic-giangq4">Max Score</td><td class="td-topic-giangq4">Passing Score</td><td class="td-topic-giangq4">Weighted Number</td></tr>');
            // topic selected
            for (let k = 0; k < listMilestoneTopics.length; k++) {
                $("tbody#tbody-giangnq4").append('<tr class = "topic' + rowCount + '-' + rowCountChild + '" id="' + rowCount + '-' + rowCountChild + '-'+k+'"><td id="' + listMilestoneTopics[k]["milestoneId"] + '"></td><td><i class="fa fa-trash" id="deleteTopic"></i></div></td><td><div class="form-group"><select class="form-control giangnq4IdMileClass' + rowCount + '" id="giangnq4IdMileId' + idSelect + '"></select></div></td><td><div class="form-group"><select class="form-control maxScore' + rowCount + '" id="giangnq4IdMaxScore' + idMaxScore + '"></select></div></td><td><div class="form-group"><select class="form-control passingScore' + rowCount + '" id="giangnq4IdPassingScore' + idPassingScore + '"></select></div></td><td><div class="form-group"><select class="form-control weightedNumber' + rowCount + '" id="giangnq4IdWeightedNumberId' + idWeightedNumber + '"></select></div></td></tr>');

                var topics = listMilestoneTopics[k]["topic"]["topicId"];
                var maxScoreSelected = listMilestoneTopics[k]["max_score"];
                var passingScoreSelected = listMilestoneTopics[k]["passingScore"];
                var weightedNumberSelected = listMilestoneTopics[k]["weightedNumber"];
                for (let i = 0; i < myArray.length - 1; i++) {
                    for (let m = i + 1; m < myArray.length; m++) {
                        if (myArray[i] == topics) {
                            $('select#giangnq4IdMileId' + idSelect).append('<option selected value="' + myArray[i] + '">' + myArray[m] + '</option>');
                        } else {
                            $('select#giangnq4IdMileId' + idSelect).append('<option value="' + myArray[i] + '">' + myArray[m] + '</option>');
                        }
                        i = m;
                        break;
                    }
                }
                
                for (let i = 0; i <= 20; i++) {
                	if (maxScoreSelected == listMaxScores[i]) {
                		$('select#giangnq4IdMaxScore' + idMaxScore).append('<option selected value="' + listMaxScores[i] + '">' + listMaxScores[i] + '</option>');
                    } else {
                        $('select#giangnq4IdMaxScore' + idMaxScore).append('<option value="' + listMaxScores[i] + '">' + listMaxScores[i] + '</option>');
                    }
				}
                
                // idPassingScore
                for (let i = 0; i <= 20; i++) {
                	if (passingScoreSelected == listMaxScores[i]) {
                		$('select#giangnq4IdPassingScore' + idPassingScore).append('<option selected value="' + listMaxScores[i] + '">' + listMaxScores[i] + '</option>');
                    } else {
                        $('select#giangnq4IdPassingScore' + idPassingScore).append('<option value="' + listMaxScores[i] + '">' + listMaxScores[i] + '</option>');
                    }
				}
                // idWeightedNumber
                for (let i = 0; i <= 20; i++) {
                	if (weightedNumberSelected == listMaxScores[i]) {
                		$('select#giangnq4IdWeightedNumberId' + idWeightedNumber).append('<option selected value="' + listMaxScores[i] + '">' + listMaxScores[i] + '</option>');
                    } else {
                        $('select#giangnq4IdWeightedNumberId' + idWeightedNumber).append('<option value="' + listMaxScores[i] + '">' + listMaxScores[i] + '</option>');
                    }
				}
                
                idSelect++;
                idMaxScore++;
                idPassingScore++;
                idWeightedNumber++;
            }

        }
    }

    // convert date
    function convertDate(dateTemp) {
        var d = new Date(dateTemp);
        var month = d.getMonth() + 1;
        var day = d.getDate();
        var output = (('' + month).length < 2 ? '0' : '') + month + '/' + (('' + day).length < 2 ? '0' : '') + day + '/' + d.getFullYear();
        return output;
    }
    // submit trainee
    $("#page-wrapper").on('click', '#updateResultButton', function (event) {
        event.preventDefault();
        var idbk = $("#idTraineeHidden").val();
        var contextPath = $(this).attr("contextPath");
        var token = $("button#updateResultButton").val();
        var header = "X-CSRF-TOKEN";
        $(document).ajaxSend(function (e, xhr, options) {
            xhr.setRequestHeader(header, token);
        });

        var milestones = [];
        for (let i = 0; i < $(".milestone").length; i++) {
            var milestoneId = $($($(".milestone")[i]).parent()).attr("id");
            var giangqn4test = $($(".milestone")[i]).parent().parent().next().attr("id");
            var milestoneTopics = [];

            for (let j = 0; j < $($(".topic" + giangqn4test)).length; j++) {
                if (i == 0) {
                    var km = $($(".topic" + giangqn4test)[0]).prev().prev().attr("id");
                } else {
                    var km = $($(".topic" + giangqn4test)[0]).prev().prev().attr("id");
                }
                var topicId = $($("select.giangnq4IdMileClass" + km)[j]).find(":selected").val();
                var topicName = $($("select.giangnq4IdMileClass" + km)[j]).find(":selected").text();
                var max_score = $($("select.maxScore" + km)[j]).find(":selected").text();
                var passingScore = $($("select.passingScore" + km)[j]).find(":selected").text();
                var weightedNumber = $($("select.weightedNumber" + km)[j]).find(":selected").text();
                var milestoneTopicIdTemp = $($($(".topic" + giangqn4test)[j]).children()[0]).attr("id");
                if (milestoneTopicIdTemp != undefined) {
                    milestoneTopicIdTemp = $($($(".topic" + giangqn4test)[j]).children()[0]).attr("id");
                } else {
                    milestoneTopicIdTemp = 0;
                }

                var milestoneTopic = {
                    "milestoneId": milestoneTopicIdTemp,
                    "max_score": max_score,
                    "passingScore": passingScore,
                    "weightedNumber": weightedNumber,
                    "topic": {
                        "topicId": topicId,
                        "topicName": topicName
                    },
                }
                milestoneTopics.push(milestoneTopic);
            }

            milestoneId = milestoneId.substring(milestoneId.length - 1);
            var milestoneName = $($(".milestone")[i]).parent().next().children().children().children().val();
            var salaryPaid = $($($(".milestone")[i]).parent().next().next().children().children()).find(":selected").val();
            var startDate = new Date($($(".milestone")[i]).parent().next().next().next().children().children().children().val());
            var endDate = new Date($($(".milestone")[i]).parent().next().next().next().next().children().children().children().val());
            var milestone = {
                "milestoneId": milestoneId,
                "milestoneName": "Th2-2018",
                "salaryPaid": salaryPaid,
                "startDate": startDate,
                "endDate": endDate,
                "milestoneTopics": milestoneTopics
            }
            milestones.push(milestone);
        }
        console.log(milestones);

        var d = new Date();
        var month = d.getMonth() + 1;
        var day = d.getDate();

        var traineeProfileId = $('#traineeProfileId').val();

        var universityId = $('#university-value').attr('universityId');
        var universityName = $('#university-value').html();
        var facultyId = $('#faculty-value').attr('facultyId');
        var facultyName = $('#faculty-value').html();
        var allowanceGroupId = $('#allowanceGroup-value').attr('allowanceGroupId');
        var allowanceGroupName = $('#allowanceGroup-value').html();

        var fullName = $('#fullName').val();
        var gender = $("input[name='gender']:checked").val();
        var email = $('#email').val();
        var phone = $('#phone').val();
        var account = $('#account').val();
        var tpBank = $('#tpBank').val();
        var type = $('#type').val();
        var userId = $('#userId').val();
        var dob = new Date($('#datepicker').val());
        var listHistory = [];
        var dateNow = new Date;

        var singleUser = {
            "id": userId
        }

        var singleHistory = {
            "historyChange": dateNow.getTime(),
            "userModifiedId": singleUser
        }
        listHistory.push(singleHistory);

        var salaryElement = $("input[name='salary-paid']:checked").val();
        var otherUniversity = $("input[name='university-input']:checked").val();
        var otherFaculty = $("input[name='faculty-input']:checked").val();

        if (otherUniversity == 'other') {
            universityId = 0;
            universityName = $('#other-university').val();
        }

        if (otherFaculty == 'other') {
            facultyId = 0;
            facultyName = $('#other-faculty').val();
        }
        var output = d.getFullYear() + '/' +
            (month < 10 ? '0' : '') + month + '/' +
            (day < 10 ? '0' : '') + day;

        var University = {
            "universityId": universityId,
            "universityName": universityName
        }

        var Faculty = {
            "facultyId": facultyId,
            "facultyName": facultyName
        }

        var traineeProfiles = {
            "traineeProfileId": traineeProfileId,
            "universityId": University,
            "facultyId": Faculty,
            "fullName": fullName,
            "gender": gender,
            "email": email,
            "phone": phone,
            "account": account,
            "tpBank": tpBank,
            "type": type,
            "dob": dob,
        }

        var AllowanceGroup = {
            "allowanceGroupId": allowanceGroupId,
            "allowanceGroupName": allowanceGroupName
        }

        if (salaryElement == 'no') {
            AllowanceGroup = null
        }

        var trainee = JSON.stringify({
            "traineeId": idTraineeHidden,
            "salaryPaid": 1,
            "classId": 1,
            "attendanceStatusId": 1,
            "statusId": 1,
            "allowanceGroupId": AllowanceGroup,
            "traineeProfiles": traineeProfiles,
            "milestones": milestones,
            "listHistory": listHistory
        });
        var settings = {
            "crossDomain": true,
            "url": contextPath + "/panel/updateMile",
            "method": "POST",
            "headers": {
                "Content-Type": "application/json",
            },
            "data": trainee
        };
        $.ajax(settings).done(function (responseText) {
            alert('Success!');
        }).fail((response) => {
            alert("error" + response);
        });
    });
});
