$(document).ready(function() {
	
	(function updateMilestone() {
		$('#datepicker-dob').datepicker({
			uiLibrary : 'bootstrap'
		});
	})();
	
	var dateCreated = $('#dateCreated').attr('value');
	var dateCreatedJSConvert = new Date(dateCreated);
	var timeNow = new Date(Date.now()) ;
	var monthDistance = (timeNow.getFullYear()*12 + timeNow.getMonth()) - (dateCreatedJSConvert.getFullYear()*12 + dateCreatedJSConvert.getMonth());
	
	$('#monthDistance').html(monthDistance);
	
});
