DROP DATABASE HN_FR_JAVA_18_09_AdminBoard_G3
GO
CREATE DATaBASE HN_FR_JAVA_18_09_AdminBoard_G3
GO
USE HN_FR_JAVA_18_09_AdminBoard_G3
GO
create schema giangnq4
GO
create schema Trainee
GO
create schema TienNV29

GO
CREATE PROC giangnq4.usp_searchPagingTrainee(
	@PageSize	INT,
	@PageNumber INT,
	@emplId		INT,
	@dob		DATE,
	@account	NVARCHAR(100),
	@phone		NVARCHAR(20),
	@fullName   NVARCHAR(100),
	@email		NVARCHAR(100),
	@totalrow   INT = 0 OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @sqlString NVARCHAR(500) = 'SELECT * FROM [HN_FR_JAVA_18_09_AdminBoard_G3].[giangnq4].[TraineeProfile]';
	IF ((@emplId IS NULL OR @emplId = 0) AND (@dob IS NULL OR @dob = '') AND (@account IS NULL OR @account = '') AND (@phone IS NULL OR @phone = '') AND (@fullName IS NULL OR @fullName = '') AND (@email IS NULL OR @email = ''))
		BEGIN
			SET @sqlString += '';
		END
	ELSE 
		BEGIN
			SET @sqlString += ' WHERE 1 = 1 '
				IF (@emplId IS NOT NULL AND @emplId != 0)
					BEGIN
						SET @sqlString += 'AND [profile_id] ='+ CAST(@emplId AS NVARCHAR(10))
						print @sqlString
					END
				IF (@dob IS NOT NULL AND @dob != '')
					BEGIN
						SET @sqlString += 'AND [dob] ='
						SET @sqlString += ''''+CONVERT(varchar(10),@dob,111)+''''
					END
				IF (@account IS NOT NULL AND @account != '')
					BEGIN
						SET @sqlString += 'AND [account] ='''+ @account + ''''
					END
				IF (@phone IS NOT NULL AND @phone != '')
					BEGIN
						SET @sqlString += 'AND [phone] ='''+ @phone + ''''
					END
				IF (@fullName IS NOT NULL AND @fullName != '')
					BEGIN
						SET @sqlString += 'AND [fullname] ='''+ @fullName + ''''
					END
				IF (@email IS NOT NULL AND @email != '')
					BEGIN
						SET @sqlString += 'AND [email] ='''+ @email + ''''
					END
		END
			
		DECLARE @table TABLE 
		(
			profile_id	int,
			account	varchar(255),
			created_date	date,
			dob	date	,
			email	varchar(255),
			fullname	varchar(255),
			gender	varchar(255)	,
			phone	varchar(255)	,
			tpBank	varchar(255)	,
			type	varchar(255)	,
			updated_date	date	,
			faculty_id	int	,
			university_id	int	
		);

		DECLARE @indexCurrent INT = (@PageNumber-1) * @PageSize
		print @sqlString
		INSERT INTO @table EXECUTE sp_executesql @sqlString

		SELECT * FROM @table 

		ORDER BY profile_id OFFSET @indexCurrent
		ROWS FETCH NEXT @PageSize ROWS ONLY

		DECLARE @totalrowtemp INT
		SET @totalrowtemp = (SELECT COUNT(*) FROM @table)
		SET @totalrow = @totalrowtemp / @PageSize + 1
		
END
GO

EXEC giangnq4.usp_searchPagingTrainee 10,1,0,'','','','',''

GO

INSERT INTO TienNV29.users(username,[password],[enabled])
VALUES
('alo','$2a$04$GYGsaJj9l6kH2GikK6QVzO0v3sOCxt3vdkiA2/tcoSw8erI85ZYDG','1'),
('hello','$2a$04$GYGsaJj9l6kH2GikK6QVzO0v3sOCxt3vdkiA2/tcoSw8erI85ZYDG','1')
GO

INSERT INTO TienNV29.[role](name)
VALUES
('ROLE_ADMIN')
GO

INSERT INTO TienNV29.users_roles(user_id,role_id)
VALUES
('1','1'),
('2','1')

GO

INSERT INTO Trainee.AllowanceGroup
VALUES
('DEV-1'),
('DEV-2'),
('DEV-3'),
('DEV-4'),
('DEV-5'),
('FRESHER')
GO

INSERT INTO Trainee.University
VALUES
('HUST'),
('FPT'),
('PVU'),
('HNU'),
('VNU'),
('CKU')
GO

INSERT INTO Trainee.Faculty
VALUES
('PeterQV1'),
('JohnDD2'),
('MayJJ15'),
('JaneKN9'),
('LeeMN1'),
('KimUH3')
GO



	INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2017','2-3-2019','TienNV29@fsoft.com.vn',1,'Nguyen Viet Tien','male','123456789','tpbank','type',1,'2-2-1992','TienNV29')
   
   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','11-22-2019','KhaiTQ3@fsoft.com.vn',1,'Tran Quang Khai','male','123456789','tpbank','type',1,'2-2-1992','KhaiTQ3')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','11-22-2019','GiangNQ4@fsoft.com.vn',1,'Nguyen Quang Giang','male','123456789','tpbank','type',1,'2-2-1992','GiangNQ4')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','5-7-2019','quanghv@fsoft.com.vn',1,'Nguyen Hong Quang','male','0914887965','tpbank','type',1,'2-2-1992','quanghv')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','5-6-2019','HaiNT53@fsoft.com.vn',1,'Nguyen Hong Quang','male','123456789','tpbank','type',1,'2-2-1992','HaiNT53')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','5-3-2019','DungHNA@fsoft.com.vn',1,'Ho Ngoc Anh Dung','male','123456789','tpbank','type',1,'2-2-1992','DungHNA')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','9-3-2019','OanhNTV@fsoft.com.vn',1,'Ho Ngoc Anh Dung','male','123456789','tpbank','type',1,'2-2-1992','OanhNTV')
   
   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','3-25-2019','CuongNL6@fsoft.com.vn',1,'Ho Ngoc Anh Dung','male','123456789','tpbank','type',1,'2-2-1992','CuongNL6')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','3-15-2019','PhuocDT@fsoft.com.vn',1,'Ho Ngoc Anh Dung','male','123456789','tpbank','type',1,'2-2-1992','PhuocDT')
   
   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','3-3-2019','HauNV7@fsoft.com.vn',1,'Ho Ngoc Anh Dung','male','123456789','tpbank','type',1,'2-2-1992','HauNV7')

   INSERT INTO giangnq4.TraineeProfile(created_date,dob,email,faculty_id,fullname,gender,phone,tpBank,type,university_id,updated_date,account)
   VALUES('2-2-2016','5-3-2019','AnNV16@fsoft.com.vn',1,'Ho Ngoc Anh Dung','male','123456789','tpbank','type',1,'2-2-1992','AnNV16')
GO

  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(1,1,1,1,1,1)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(2,2,2,2,2,2)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(1,1,1,1,1,3)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(2,2,2,2,2,4)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(1,1,1,1,1,5)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(2,2,2,2,2,6)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(1,1,1,1,1,7)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(2,2,2,2,2,8)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(1,1,1,1,1,9)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(2,2,2,2,2,10)
  INSERT INTO giangnq4.Trainee(allowance_group_id,attendance_status_id,class_id,salary_paid,status_id,trainee_profile_id) VALUES(1,1,1,1,1,11)

GO

   
   INSERT INTO giangnq4.Milestone(endDate,milestone_name,salary_paid,startDate,trainee_id) 
   VALUES('2-2-1992','Thang 2',1222,'2-3-1992',1)
    INSERT INTO giangnq4.Milestone(endDate,milestone_name,salary_paid,startDate,trainee_id) 
   VALUES('2-2-1992','Thang 3',1222,'2-3-1992',2)

   GO

   INSERT INTO giangnq4.Topic(topic_name) VALUES('JAVA CORE')
   INSERT INTO giangnq4.Topic(topic_name) VALUES('JAVA WEB')
   INSERT INTO giangnq4.Topic(topic_name) VALUES('HIBERNATE')
   INSERT INTO giangnq4.Topic(topic_name) VALUES('JAVA CORE1')

   GO

   INSERT INTO giangnq4.Milestone_Topic(max_score,passing_score,weighted_number,milestone_id,topic_id)
   VALUES(10,3,2,1,1)
   INSERT INTO giangnq4.Milestone_Topic(max_score,passing_score,weighted_number,milestone_id,topic_id)
   VALUES(10,3,2,2,2)

   
INSERT INTO Trainee.History(history_change,trainee_id,user_modified_id)
VALUES
('2018-01-12','1','1'),
('2017-01-12','1','1'),
('2016-01-12','2','1'),
('2015-01-12','1','1'),
('2013-01-12','2','1'),
('2012-01-12','1','1')
GO


INSERT INTO Trainee.Location(location_name)
VALUES
('Hanoi'),
('Saigon'),
('Seoul')
GO

INSERT INTO Trainee.ClassBatch(class_name,location_id,planning_trainee_number,planed_trainee_number,inprocess_trainee_number, [status])
VALUES
('.Net', 1, 130, 50, 20,1),
('.Android', 2, 130, 50, 20,2),
('.Java', 1, 130, 50, 20,3),
('.Python', 1, 130, 50, 20,1),
('.Pascal', 2, 130, 50, 20,2),
('.JS', 3, 130, 50, 20,2)
GO
