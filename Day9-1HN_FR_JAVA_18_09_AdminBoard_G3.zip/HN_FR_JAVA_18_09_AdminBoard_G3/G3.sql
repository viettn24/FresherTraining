CREATE DATABASE HN_FR_JAVA_18_09_AdminBoard_G3
GO
--DROP DATABASE HN_FR_JAVA_18_09_AdminBoard_G3
USE HN_FR_JAVA_18_09_AdminBoard_G3
GO

/* Login - Role - Table */
CREATE TABLE dbo.Roles
(
	role_id INT IDENTITY(1,1) PRIMARY KEY,
	role_name VARCHAR(255) NOT NULL UNIQUE
)
GO

CREATE TABLE dbo.Users 
(
	u_id INT IDENTITY(1,1) PRIMARY KEY,
	user_account VARCHAR(255) NOT NULL,
	[password] VARCHAR(255) NOT NULL,
	role_id INT,
	CONSTRAINT fk_users_roles FOREIGN KEY (role_id) REFERENCES dbo.Roles(role_id) 
)
GO

INSERT INTO dbo.Roles
        ( role_name )
VALUES  ( 'FA.Manager' ),
		( 'FA.Rec' ),
		( 'Delivery manager' ),
		( 'Class admin' ),
		( 'Trainer' )
GO

SELECT * FROM dbo.Roles ORDER BY role_id
GO

INSERT INTO dbo.Users
        (
          user_account ,
          [password] ,
          role_id
        )
VALUES  ('admin1','admin1', 1),
		('admin2','admin2', 2),
		('admin3','admin3', 3),
		('admin4','admin4', 4),
		('admin5','admin5', 5)
GO



/* Requirement Table */

CREATE SCHEMA giangnq4
GO

CREATE TABLE Trainee.University 
(
	university_id INT IDENTITY(1,1) PRIMARY KEY,
	university_name NVARCHAR(255) NOT NULL
)
GO

CREATE TABLE Trainee.Falcuty
(
	falcuty_id INT IDENTITY(1,1) PRIMARY KEY,
	falcuty_name VARCHAR(255) NOT NULL
)

GO

CREATE TABLE Trainee.[Status]
(
	status_id INT IDENTITY(1,1) PRIMARY KEY,
	status_name VARCHAR(255) NOT NULL UNIQUE
)
GO

CREATE TABLE Trainee.AttendanceStatus
(
	attendance_status_id INT IDENTITY(1,1) PRIMARY KEY,
	attendance_status_name VARCHAR(255) NOT NULL UNIQUE
)
GO

CREATE TABLE Trainee.Location 
(
	location_id INT IDENTITY(1,1) PRIMARY KEY,
	location_name VARCHAR(255) NOT NULL UNIQUE
)
GO

CREATE TABLE Trainee.ClassBatch 
(
	class_id INT IDENTITY(1,1) PRIMARY KEY,
	class_name VARCHAR(255) NOT NULL UNIQUE,
	location_id INT,
	planed_trainne_number INT,
	inprogress_trainee_number INT,
	planning_trainee_number INT,
	CONSTRAINT fk_Class_Location FOREIGN KEY (class_id) REFERENCES Trainee.Location(location_id)
)
GO

CREATE TABLE Trainee.AllowanceGroup
(
	allowance_group_id INT IDENTITY(1,1) PRIMARY KEY,
	group_name VARCHAR(255) NOT NULL UNIQUE
)
GO

CREATE TABLE Trainee.Topic
(
	topic_id INT IDENTITY(1,1) PRIMARY KEY,
	topic_name VARCHAR(255) NOT NULL UNIQUE
)
GO

CREATE TABLE Trainee.Trainees 
(
	trainee_id INT IDENTITY(1,1) PRIMARY KEY,
	salary_paid BIT,
	class_id INT NOT NULL,
	attendance_status_id INT NOT NULL,
	status_id INT NOT NULL,
	allowance_group_id INT NOT NULL,
	CONSTRAINT fk_trainee_clazz FOREIGN KEY (class_id) REFERENCES Trainee.ClassBatch(class_id),
	CONSTRAINT fk_trainee_attendacne FOREIGN KEY (attendance_status_id) REFERENCES Trainee.AttendanceStatus(attendance_status_id),
	CONSTRAINT fk_trainee_allowance FOREIGN KEY (allowance_group_id) REFERENCES Trainee.AllowanceGroup(allowance_group_id),
	CONSTRAINT fk_trainne_status FOREIGN KEY (status_id) REFERENCES Trainee.[Status](status_id)
)
GO

CREATE TABLE Trainee.TraineeProfile
(
	profile_id INT IDENTITY(1,1) PRIMARY KEY,
	trainee_id INT,
	university_id INT,
	falcuty_id INT,
	fullname VARCHAR(255),
	dob DATE,
	gender CHAR(20),
	email VARCHAR(100),
	phone VARCHAR(20),
	tpBank VARCHAR(30),
	[type] VARCHAR(20),
	CONSTRAINT fk_profile_trainee FOREIGN KEY (trainee_id) REFERENCES Trainee.Trainees(trainee_id),
	CONSTRAINT fk_profile_university FOREIGN KEY (university_id) REFERENCES Trainee.University(university_id),
	CONSTRAINT fk_profile_falcuty FOREIGN KEY (falcuty_id) REFERENCES Trainee.Falcuty(falcuty_id),
	created_date DATE,
	updated_date DATE
)
GO

CREATE TABLE Trainee.History 
(
	history_id INT IDENTITY(1,1) PRIMARY KEY,
	trainee_id INT,
	history_log VARCHAR(255),
	CONSTRAINT fk_history_trainee FOREIGN KEY (trainee_id) REFERENCES Trainee.Trainees(trainee_id)
)
GO

CREATE TABLE giangnq4.Milestone 
(
	milestone_id INT IDENTITY(1,1) PRIMARY KEY,
	trainee_id INT,
	milestone_name VARCHAR(255) NOT NULL,
	salary_paid BIT,
	startDate DATE,
	endDate DATE,
	CONSTRAINT fk_milestone_trainee FOREIGN KEY (trainee_id) REFERENCES giangnq4.Trainee(trainee_id)
)
GO

CREATE TABLE giangnq4.Milestone_Topic
(
	milestone_id INT,
	topic_id INT,
	max_score INT,
	passing_score INT,
	weighted_number INT,
	CONSTRAINT fk_with_Milestone FOREIGN KEY (milestone_id) REFERENCES Trainee.Milestone(milestone_id),
	CONSTRAINT fk_with_topic FOREIGN KEY (topic_id) REFERENCES Trainee.Topic(topic_id)
)
GO

/*.....*/

--giangnq4