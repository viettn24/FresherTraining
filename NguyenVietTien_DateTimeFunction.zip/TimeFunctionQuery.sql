/*
1. Higher-Precision System Date and Time Functions
*/
SELECT SYSDATETIME();
SELECT SYSDATETIMEOFFSET();
SELECT SYSUTCDATETIME();



/*
2. Lower-Precision System Date and Time Functions
*/
SELECT CURRENT_TIMESTAMP;
SELECT GETDATE();
SELECT GETUTCDATE();



/*
3. Functions That Return Date and Time Parts
*/
SELECT DATENAME (MONTH,GETDATE());   /* Return String */
SELECT DATEPART (MONTH,GETDATE());	 /* Return Int */
SELECT DAY (GETDATE());
SELECT MONTH (GETDATE());
SELECT YEAR (GETDATE());



/*
4. Functions That Return Date and Time Values from Their Parts
*/
SELECT DATEFROMPARTS (2018, 10, 16);
SELECT DATETIMEFROMPARTS (2018, 12, 30, 19, 30, 15, 122)



/*
5. Functions That Return Date and Time Difference Values
*/
DECLARE @date1 DATETIME
DECLARE @date2 DATETIME
SET @date1 = '2018-01-30 20:20:15.123'
SET @date2 = '2019-03-21 20:20:15.123'
SELECT DATEDIFF (MONTH,@date1,@date2) AS Month_Result;



/*
6. Functions That Modify Date and Time Values
*/
SELECT DATEADD(MONTH, 1, '2017/08/25') AS DateAdd;
SELECT EOMONTH(GETDATE(),19) AS Date_Now_add_19_months
SELECT SWITCHOFFSET(SYSDATETIMEOFFSET(), '+00:00')
SELECT TODATETIMEOFFSET(GETDATE(), '+00:00')


/*
7.Other Function
*/
USE Fsoft_Demo;

SET LANGUAGE ENGLISH;
SET LANGUAGE KOREAN;
SELECT @@LANGUAGE

SELECT @@DATEFIRST
SET DATEFIRST 3

IF ISDATE('2009-05-12 10:19:41.177') = 1
    PRINT 'VALID'  
ELSE  
    PRINT 'INVALID';  









