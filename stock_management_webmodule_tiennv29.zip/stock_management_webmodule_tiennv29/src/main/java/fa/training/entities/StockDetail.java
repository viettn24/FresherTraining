package fa.training.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity(name = "StockDetail")
@Table(name = "StockDetail", schema="stock")
public class StockDetail {
  private int stockId;
  private String companyName;
  private String companyAddress;
  private String remark;
  private Date listedDate;
  private Stock stock;
  public StockDetail() {
  }
  public StockDetail(String companyName, Date listedDate) {
    this.companyName = companyName;
    this.listedDate = listedDate;
  }
  public StockDetail(String companyName, String companyAddress, String remark,
      Date listedDate) {
    this.companyName = companyName;
    this.companyAddress = companyAddress;
    this.remark = remark;
    this.listedDate = listedDate;
  }
  
  @Id
  @Column(name = "stock_id", nullable=false, unique = true)
  public int getStockId() {
    return stockId;
  }
  public void setStockId(int stockId) {
    this.stockId = stockId;
  }
  
  @Column(name = "company_name", length=100)
  public String getCompanyName() {
    return companyName;
  }
  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }
  
  @Column(name = "company_address", length = 200)
  public String getCompanyAddress() {
    return companyAddress;
  }
  public void setCompanyAddress(String companyAddress) {
    this.companyAddress = companyAddress;
  }
  
  @Column(name = "remark", length =255)
  public String getRemark() {
    return remark;
  }
  public void setRemark(String remark) {
    this.remark = remark;
  }
  
  @Column(name="listed_date", length=10)
  public Date getListedDate() {
    return listedDate;
  }
  public void setListedDate(Date listedDate) {
    this.listedDate = listedDate;
  }
  
  @MapsId
  @OneToOne
  @JoinColumn(name = "stock")
  public Stock getStock() {
    return stock;
  }
  public void setStock(Stock stock) {
    this.stock = stock;
  }
  
  
}
