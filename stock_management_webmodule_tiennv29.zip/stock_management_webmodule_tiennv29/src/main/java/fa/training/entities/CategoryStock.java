package fa.training.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "CategoryStock")
@Table(name = "CategoryStock", schema = "stock")
public class CategoryStock {
  
  @EmbeddedId
  private CategoryStockPK id;
  
  @ManyToOne
  @JoinColumn(name="category_id", insertable = false, updatable = false)
  private Category category;
  
  @ManyToOne
  @JoinColumn(name = "stock_id", insertable = false, updatable = false)
  private Stock stock;
  
  public CategoryStock() {
  }

  public CategoryStockPK getId() {
    return id;
  }

  public void setId(CategoryStockPK id) {
    this.id = id;
  }

  public Category getCategory() {
    return category;
  }

  public void setCategory(Category category) {
    this.category = category;
  }

  public Stock getStock() {
    return stock;
  }

  public void setStock(Stock stock) {
    this.stock = stock;
  }
  
  
  
  
}
