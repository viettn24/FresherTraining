package fa.training.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CategoryStockPK implements Serializable {
  
  @Column(name="category_id")
  private int categoryId;
  
  @Column(name = "stock_id")
  private int stockId;

  public CategoryStockPK() {
  }

  public int getCategoryId() {
    return categoryId;
  }

  public void setCategoryId(int categoryId) {
    this.categoryId = categoryId;
  }

  public int getStockId() {
    return stockId;
  }

  public void setStockId(int stockId) {
    this.stockId = stockId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + categoryId;
    result = prime * result + stockId;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    CategoryStockPK other = (CategoryStockPK) obj;
    if (categoryId != other.categoryId)
      return false;
    if (stockId != other.stockId)
      return false;
    return true;
  }


  
}
