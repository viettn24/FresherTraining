package fa.training.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "StockDailyRecord", schema="stock")
public class StockDailyRecord {
  private int record_id;
  private Date dated;
  private float price_change;
  
  private Stock stock;

  public StockDailyRecord() {
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public int getRecord_id() {
    return record_id;
  }

  public void setRecord_id(int record_id) {
    this.record_id = record_id;
  }

  public Date getDated() {
    return dated;
  }

  public void setDated(Date dated) {
    this.dated = dated;
  }

  public float getPrice_change() {
    return price_change;
  }

  public void setPrice_change(float price_change) {
    this.price_change = price_change;
  }

  @ManyToOne
  @JoinColumn(name="stock")
  public Stock getStock() {
    return stock;
  }

  public void setStock(Stock stock) {
    this.stock = stock;
  }
  
  
}
