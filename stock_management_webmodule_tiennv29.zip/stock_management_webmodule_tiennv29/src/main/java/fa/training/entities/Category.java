package fa.training.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity(name = "Category")
@Table(name= "Category", schema = "stock", uniqueConstraints = {@UniqueConstraint(columnNames = {"category_name"})})
public class Category {
  private int categoryId;
  private String categoryCode;
  private String categoryName;
  private String description;
  private Set<CategoryStock> categoryStocks;
  public Category() {
  }
  public Category(String categoryCode, String categoryName,
      String description) {
    this.categoryCode = categoryCode;
    this.categoryName = categoryName;
    this.description = description;
  }
  
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="category_id")
  public int getCategoryId() {
    return categoryId;
  }
  public void setCategoryId(int categoryId) {
    this.categoryId = categoryId;
  }
  
  @Column(name= "category_code", length = 7, nullable =true, unique = true)
  public String getCategoryCode() {
    return categoryCode;
  }
  
  public void setCategoryCode(String categoryCode) {
    this.categoryCode = categoryCode;
  }
  
  @Column(name="category_name")
  public String getCategoryName() {
    return categoryName;
  }
  
  public void setCategoryName(String categoryName) {
    this.categoryName = categoryName;
  }
  
  @Column(name="description", length = 200)
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
 
  @OneToMany(mappedBy = "category", fetch= FetchType.LAZY, cascade = CascadeType.ALL)
  public Set<CategoryStock> getCategoryStocks() {
    return categoryStocks;
  }
  public void setCategoryStocks(Set<CategoryStock> categoryStocks) {
    this.categoryStocks = categoryStocks;
  }
  @Override
  public String toString() {
    return "Category [categoryCode=" + categoryCode + ", categoryName="
        + categoryName + ", description=" + description + "]";
  }
  
  
  
}
