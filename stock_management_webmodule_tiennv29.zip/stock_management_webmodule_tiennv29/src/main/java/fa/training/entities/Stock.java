package fa.training.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity(name = "Stock")
@Table(name = "Stock", schema = "stock", uniqueConstraints = {@UniqueConstraint(columnNames = {"stock_code"})})
public class Stock {
  private int stockId;
  private String stockCode;
  private String stockName;
  private StockDetail stockDetail;
  private Set<StockDailyRecord> dailyRecords;
  private Set<CategoryStock> categoryStocks;
  public Stock() {
  }
  public Stock(String stockCode, String stockName) {
    this.stockCode = stockCode;
    this.stockName = stockName;
  }
  public Stock(int stockId, String stockCode, String stockName) {
    this.stockId = stockId;
    this.stockCode = stockCode;
    this.stockName = stockName;
  }
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "stock_id")
  public int getStockId() {
    return stockId;
  }
  public void setStockId(int stockId) {
    this.stockId = stockId;
  }
  
  @Column(name="stock_code", length = 10, nullable = false, unique = true)
  public String getStockCode() {
    return stockCode;
  }
  public void setStockCode(String stockCode) {
    this.stockCode = stockCode;
  }
  
  @Column(name="stock_name", length = 30, nullable = false, unique=true)
  public String getStockName() {
    return stockName;
  }
  public void setStockName(String stockName) {
    this.stockName = stockName;
  }
  
  @OneToOne(mappedBy = "stock", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
  public StockDetail getStockDetail() {
    return stockDetail;
  }
  public void setStockDetail(StockDetail stockDetail) {
    this.stockDetail = stockDetail;
  }
  
  @OneToMany(mappedBy = "stock", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
  public Set<StockDailyRecord> getDailyRecords() {
    return dailyRecords;
  }
  public void setDailyRecords(Set<StockDailyRecord> dailyRecords) {
    this.dailyRecords = dailyRecords;
  }
  
  @OneToMany(mappedBy = "stock", fetch=FetchType.LAZY)
  public Set<CategoryStock> getCategoryStocks() {
    return categoryStocks;
  }
  public void setCategoryStocks(Set<CategoryStock> categoryStocks) {
    this.categoryStocks = categoryStocks;
  }
  @Override
  public String toString() {
    return "Stock [stockId=" + stockId + ", stockCode=" + stockCode
        + ", stockName=" + stockName + "]";
  }
  
  
}
