package fa.training.dao;

import fa.training.entities.User;

public interface UserDao {
  User login(User user) throws Exception;
}
