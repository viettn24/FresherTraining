package fa.training.dao;

import org.hibernate.Session;
import org.hibernate.query.Query;

import fa.training.entities.User;
import fa.training.utils.HibernateUtil;
import fa.training.utils.Log4J;

public class UserDaoImpl implements UserDao {

  @SuppressWarnings("unchecked")
  @Override
  public User login(User user) throws Exception {
    Session session = null;
    try {
      session = HibernateUtil.getSessionAndBeginTransaction();
      Query query = session.createQuery(
          "FROM Users u WHERE u.userName=:theUserName AND u.password=:thePassword");
      query.setParameter("theUserName", user.getUserName());
      query.setParameter("thePassword", user.getPassword());
      return (User) query.list().get(0);
    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
      throw new Exception();
    } finally {
      HibernateUtil.closeCurrentSessions(session);
    }

  }

}
