package fa.training.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;

import fa.training.entities.Stock;
import fa.training.entities.StockDetail;
import fa.training.utils.Constants;
import fa.training.utils.HibernateUtil;
import fa.training.utils.Log4J;
import fa.training.vo.Counter;
import fa.training.vo.StockVO;

public class StockDaoImpl implements StockDao {

  @Override
  public List<StockVO> findByPage(StockVO stockVO, int page, Counter counter)
      throws Exception {
    Session session = HibernateUtil.getSessionAndBeginTransaction();
    List<StockVO> stockVOs = null;
    try {
      CriteriaBuilder builder = session.getCriteriaBuilder();
      CriteriaQuery<StockVO> query = builder.createQuery(StockVO.class);
      Root<Stock> root = query.from(Stock.class);
      List<Predicate> listPredicate = new ArrayList<>();

      root.join("stockDetail", JoinType.INNER);
      query.select(builder.construct(StockVO.class, root.get("stockId"),
          root.get("stockCode"), root.get("stockName"),
          root.get("stockDetail").get("companyName"),
          root.get("stockDetail").get("listedDate")

      ));

      if (stockVO != null) {
        String stockCode = stockVO.getStockCode();
        String stockName = stockVO.getStockName();

        String companyName = stockVO.getCompanyName();
        Date listedDate = stockVO.getListedDate();

        if ((stockCode != null) && (stockCode != "")) {
          listPredicate.add(builder.equal(root.get("stockCode"), stockCode));
        }

        if ((stockName != null) && (stockName != "")) {
          listPredicate
              .add(builder.like(root.get("stockName"), "%" + stockName + "%"));
        }

        if ((companyName != null) && (companyName != "")) {
          listPredicate
              .add(builder.like(root.get("stockDetail").get("companyName"),
                  "%" + companyName + "%"));
        }

        if (listedDate != null) {
          listPredicate.add(builder
              .equal(root.get("stockDetail").get("listedDate"), listedDate));
        }

      }

      query.where(builder.and(listPredicate.toArray(new Predicate[] {})));

      TypedQuery<StockVO> typedQuery = session.createQuery(query);

      Long countTotal = (long) typedQuery.getResultList().size();
      counter.setCountTotal(countTotal);

      typedQuery.setFirstResult((page - 1) * Constants.PAGE_SIZE);

      typedQuery.setMaxResults(Constants.PAGE_SIZE);

      stockVOs = typedQuery.getResultList();

    } catch (Exception exception) {
      Log4J.getLogger().error(exception);
      throw new Exception();
    } finally {
      HibernateUtil.closeCurrentSessions(session);
    }
    return stockVOs;
  }

  @Override
  public void saveOrUpdate(Stock stock) throws Exception {
    Session session = null;

    try {
      session = HibernateUtil.getSessionAndBeginTransaction();

      if (stock.getStockId() != 0) {
        Stock stockPersistent = session.get(Stock.class, stock.getStockId());

        StockDetail stockDetail = session.get(StockDetail.class,
            stock.getStockId());

        stockPersistent.setStockCode(stock.getStockCode());
        stockPersistent.setStockName(stock.getStockName());

        stockPersistent.setStockDetail(stockDetail);
        stockDetail.setStock(stockPersistent);

      } else {
        session.save(stock);
      }

      session.getTransaction().commit();
    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
      System.out.println("=======Inside save stock catch exception=====");
      exception.printStackTrace();
      throw new Exception();
    } finally {
      HibernateUtil.closeCurrentSessions(session);
    }

  }

  @Override
  public Stock findById(int id) throws Exception {
    Session session = null;
    try {
      session = HibernateUtil.getSessionAndBeginTransaction();

      Stock stock = session.get(Stock.class, id);
      return stock;
    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
      throw new Exception();
    } finally {
      HibernateUtil.closeCurrentSessions(session);
    }

  }

  @Override
  public boolean deleteStock(int id) throws Exception {
    // TODO Auto-generated method stub
    return false;
  }

}
