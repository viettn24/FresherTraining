package fa.training.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.UserDao;
import fa.training.dao.UserDaoImpl;
import fa.training.entities.User;
import fa.training.services.StockService;
import fa.training.services.StockServiceImpl;
import fa.training.utils.Constants;
import fa.training.utils.Log4J;
import fa.training.utils.MessageUtil;
import fa.training.vo.Counter;
import fa.training.vo.StockVO;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public UserController() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    response.sendRedirect(request.getContextPath() + "/views/login.jsp");
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request,
      HttpServletResponse response) throws ServletException, IOException {

    String userName = request.getParameter("userName");
    String password = request.getParameter("password");

    User user = new User(userName, password);

    UserDao userDao = new UserDaoImpl();
    User loginResult = null;

    try {
      loginResult = userDao.login(user);
    } catch (Exception exception) {
      request.setAttribute("login_fail", MessageUtil.getMessage("login_fail"));
      request.getRequestDispatcher("/views/login.jsp").forward(request,
          response);
    }

    if (loginResult != null) {
      HttpSession session = request.getSession();
      session.setAttribute("user", loginResult);
    }

    StockService stockService = new StockServiceImpl();
    StockVO stockVO = null;

    try {
      Counter counter = new Counter();
      List<StockVO> stocks = stockService.findByPage(stockVO,
          Constants.INITIAL_PAGE, counter);

      int amountOfRec = counter.getCountTotal().intValue();

      int totalPage = amountOfRec / Constants.PAGE_SIZE;

      if (amountOfRec % Constants.PAGE_SIZE != 0) {
        totalPage++;
      }

      request.setAttribute("totalPage", totalPage);
      request.setAttribute("stocks", stocks);

      request.getRequestDispatcher("/views/index.jsp").forward(request,
          response);

    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
//      throw new ServletException();
    }

  }

}
