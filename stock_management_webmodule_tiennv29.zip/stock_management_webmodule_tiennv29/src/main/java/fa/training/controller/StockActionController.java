package fa.training.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import fa.training.entities.Stock;
import fa.training.entities.StockDetail;
import fa.training.services.StockService;
import fa.training.services.StockServiceImpl;
import fa.training.utils.Log4J;
import fa.training.vo.StockVO;

/**
 * Servlet implementation class StockActionController
 */
@WebServlet("/StockActionController")
public class StockActionController extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public StockActionController() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    BufferedReader bufferedReader = new BufferedReader(
        new InputStreamReader(request.getInputStream()));

    String json = "";
    if (bufferedReader != null) {
      json = bufferedReader.readLine();
    }

    ObjectMapper mapper = new ObjectMapper();

    StockVO stockVO = mapper.readValue(json, StockVO.class);

    StockService stockService = new StockServiceImpl();

    Stock stock;

    try {
      stock = stockService.findById(stockVO.getStockId());

      if (stock != null) {
        StockDetail stockDetail = stock.getStockDetail();
        stockVO.setStockCode(stock.getStockCode());
        stockVO.setStockName(stock.getStockName());
        stockVO.setCompanyName(stockDetail.getCompanyName());
        stockVO.setCompanyAddress(stockDetail.getCompanyAddress());
        stockVO.setRemark(stockDetail.getRemark());
        stockVO.setListedDate(stockDetail.getListedDate());

        response.setContentType("application/json");

        List<StockVO> stocks = new LinkedList<>();

        stocks.add(stockVO);

        mapper.writeValue(response.getOutputStream(), stocks);

      }

    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
      throw new ServletException();
    }

  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request,
      HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
