package fa.training.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import fa.training.entities.Stock;
import fa.training.entities.StockDetail;
import fa.training.services.StockService;
import fa.training.services.StockServiceImpl;
import fa.training.utils.Constants;
import fa.training.utils.Log4J;
import fa.training.utils.MessageUtil;
import fa.training.vo.Counter;
import fa.training.vo.StockVO;

/**
 * Servlet implementation class StockController
 */
@WebServlet("/StockController")
public class StockController extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public StockController() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    String stockCode = request.getParameter("stockCode");
    String stockName = request.getParameter("stockName");
    String companyName = request.getParameter("companyName");
    Date listedDate = null;

    try {
      listedDate = new Date(new SimpleDateFormat("dd/MM/yyy")
          .parse(request.getParameter("listedDate")).getTime()

      );
    } catch (ParseException exception) {
      Log4J.getLogger().error(exception.getStackTrace()[0].toString());
    }

    int currentPage = 0;

    try {
      currentPage = Integer.parseInt(request.getParameter("page"));
    } catch (Exception exception) {
      currentPage = Constants.INITIAL_PAGE;
    }

    StockVO stockVO = new StockVO(stockCode, stockName, companyName,
        listedDate);

    Counter counter = new Counter();
    counter.setCountTotal(0l);

    StockService stockService = new StockServiceImpl();

    List<StockVO> stocks = null;

    try {
      stocks = stockService.findByPage(stockVO, currentPage, counter);
      int amountOfRec = counter.getCountTotal().intValue();

      int totalPage = amountOfRec / Constants.PAGE_SIZE;
      if (amountOfRec % Constants.PAGE_SIZE != 0) {
        totalPage++;
      }
      request.setAttribute("totalPage", totalPage);
      request.setAttribute("stocks", stocks);
      request.setAttribute("stockVO", stockVO);
      request.setAttribute("currentPage", currentPage);
      request.getRequestDispatcher("/views/index.jsp").forward(request,
          response);

    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
      throw new ServletException();
    }

  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request,
      HttpServletResponse response) throws ServletException, IOException {
    BufferedReader bufferedReader = new BufferedReader(
        new InputStreamReader(request.getInputStream()));

    String json = "";
    if (bufferedReader != null) {
      json = bufferedReader.readLine();
    }

    ObjectMapper mapper = new ObjectMapper();

    StockVO stockVO = mapper.readValue(json, StockVO.class);

    Stock stock = new Stock(stockVO.getStockCode(), stockVO.getStockName());
    int stockId = stockVO.getStockId();

    if (stockId != 0) {
      stock.setStockId(stockId);
    }

    StockDetail stockDetail = new StockDetail(stockVO.getCompanyName(),
        stockVO.getCompanyAddress(), stockVO.getRemark(),
        new java.sql.Date(stockVO.getListedDate().getTime())

    );

    stock.setStockDetail(stockDetail);
    stockDetail.setStock(stock);

    String message = "No message";
    StockService stockService = new StockServiceImpl();

    try {
      stockService.saveOrUpdate(stock);

      message = MessageUtil.getMessage("save_stock_success");

    } catch (IOException ioException) {
      Log4J.getLogger().error(ioException.getMessage());
    } catch (Exception exception) {
      Log4J.getLogger().error(exception.getMessage());
      try {
        message = MessageUtil.getMessage("save_stock_fail");
      } catch (IOException ioException) {
        Log4J.getLogger().error(ioException.getMessage());
      }

    }

    PrintWriter out = response.getWriter();
    response.setContentType("text/plain");
//    out.write(message);

  }

}
