package fa.training.services;

import fa.training.entities.User;

public interface UserService {
  User login(User user) throws Exception;
}
