package fa.training.services;

import fa.training.dao.UserDao;
import fa.training.dao.UserDaoImpl;
import fa.training.entities.User;

public class UserServiceImpl implements UserService {

  @Override
  public User login(User user) throws Exception {
    UserDao userDao = new UserDaoImpl();
    return userDao.login(user);
  }

}
