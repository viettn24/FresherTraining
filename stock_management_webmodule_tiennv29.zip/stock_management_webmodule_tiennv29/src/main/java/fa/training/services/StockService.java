package fa.training.services;

import java.util.List;

import fa.training.entities.Stock;
import fa.training.vo.Counter;
import fa.training.vo.StockVO;

public interface StockService {
  List<StockVO> findByPage(StockVO stockVO, int page, Counter counter) throws Exception;
  
  void saveOrUpdate(Stock stock) throws Exception;
  
  Stock findById(int id) throws Exception;
}
