package fa.training.services;

import java.util.List;

import fa.training.dao.StockDao;
import fa.training.dao.StockDaoImpl;
import fa.training.entities.Stock;
import fa.training.vo.Counter;
import fa.training.vo.StockVO;

public class StockServiceImpl implements StockService {

  @Override
  public List<StockVO> findByPage(StockVO stockVO, int page, Counter counter)
      throws Exception {
    StockDao stockDao = new StockDaoImpl();
    return stockDao.findByPage(stockVO, page, counter);
  }

  @Override
  public void saveOrUpdate(Stock stock) throws Exception {
    StockDao stockDao = new StockDaoImpl();
    
    stockDao.saveOrUpdate(stock);

  }

  @Override
  public Stock findById(int id) throws Exception {
    StockDao stockDao = new StockDaoImpl();
    return stockDao.findById(id);
  }

}
