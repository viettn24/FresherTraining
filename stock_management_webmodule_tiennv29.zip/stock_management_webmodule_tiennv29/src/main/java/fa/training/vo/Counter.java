package fa.training.vo;

public class Counter {
  private Long countTotal;

  public Long getCountTotal() {
    return countTotal;
  }

  public void setCountTotal(Long countTotal) {
    this.countTotal = countTotal;
  }
  
  
}
