package fa.training.vo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StockVO {
  private int stockId;
  private String stockCode;
  private String stockName;
  private String companyName;
  
  private Date listedDate;
  
  private String companyAddress;
  
  private String remark;

  public StockVO() {
  }

  public StockVO(int stockId) {
    this.stockId = stockId;
  }

  public StockVO(int stockId, String stockCode, String stockName,
      String companyName, Date listedDate) {
    this.stockId = stockId;
    this.stockCode = stockCode;
    this.stockName = stockName;
    this.companyName = companyName;
    this.listedDate = listedDate;
  }

  public StockVO(String stockCode, String stockName, String companyName,
      Date listedDate) {
    this.stockCode = stockCode;
    this.stockName = stockName;
    this.companyName = companyName;
    this.listedDate = listedDate;
  }

  public StockVO(String stockCode, String stockName, String companyName,
      Date listedDate, String companyAddress, String remark) {
    this.stockCode = stockCode;
    this.stockName = stockName;
    this.companyName = companyName;
    this.listedDate = listedDate;
    this.companyAddress = companyAddress;
    this.remark = remark;
  }

  public StockVO(int stockId, String stockCode, String stockName,
      String companyName, Date listedDate, String companyAddress,
      String remark) {
    this.stockId = stockId;
    this.stockCode = stockCode;
    this.stockName = stockName;
    this.companyName = companyName;
    this.listedDate = listedDate;
    this.companyAddress = companyAddress;
    this.remark = remark;
  }

  public int getStockId() {
    return stockId;
  }

  public void setStockId(int stockId) {
    this.stockId = stockId;
  }

  public String getStockCode() {
    return stockCode;
  }

  public void setStockCode(String stockCode) {
    this.stockCode = stockCode;
  }

  public String getStockName() {
    return stockName;
  }

  public void setStockName(String stockName) {
    this.stockName = stockName;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public Date getListedDate() {
    return listedDate;
  }

  public void setListedDate(Date listedDate) {
    this.listedDate = listedDate;
  }

  public String getCompanyAddress() {
    return companyAddress;
  }

  public void setCompanyAddress(String companyAddress) {
    this.companyAddress = companyAddress;
  }

  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }
  
  
}
