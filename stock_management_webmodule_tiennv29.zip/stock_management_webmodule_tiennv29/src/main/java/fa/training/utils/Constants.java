package fa.training.utils;

public class Constants {
  public static final String ONE = "1";
  public static final String SUCCESS = "success";
  public static final String FAIL = "fail";
  public static final String COURSE_ADD = "course_add";
  public static final String COURSE_LIST = "course_list";
  public static final int PAGE_SIZE = 5;
  public static final int INITIAL_PAGE = 1;
  public static final String INITIAL_TITLE = "";
  public static final String INITIAL_CODE = "";
  public static final String ACTION = "bSearch";
  public static final String REDIRECT = "1";
  public static final String ACTIVE = "1";
  public static final int PAGE_SIE = 5;
 
}
