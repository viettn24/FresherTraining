package fa.training.utils;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import fa.training.entities.Category;
import fa.training.entities.CategoryStock;
import fa.training.entities.CategoryStockPK;
import fa.training.entities.Stock;
import fa.training.entities.StockDailyRecord;
import fa.training.entities.StockDetail;
import fa.training.entities.User;

public class HibernateUtil {
  private static Logger logger = Logger.getLogger(HibernateUtil.class);
  private static SessionFactory sessionFactory;

  static {
    PropertyConfigurator
        .configure(HibernateUtil.class.getResource("/log4jFILE.properties"));

    String hibernate_cfg_path = "/hibernate.cfg.xml";

    try {
      Configuration configuration = new Configuration();
      configuration.configure(hibernate_cfg_path);
      sessionFactory = configuration
          .addAnnotatedClass(User.class)
          .addAnnotatedClass(Category.class)
          .addAnnotatedClass(CategoryStock.class)
          .addAnnotatedClass(CategoryStockPK.class)
          .addAnnotatedClass(Stock.class)
          .addAnnotatedClass(StockDailyRecord.class)
          .addAnnotatedClass(StockDetail.class)
          
          .buildSessionFactory();
    } catch (Throwable ex) {
      logger.error("Session Factory could not be created." + ex);
      throw new ExceptionInInitializerError(ex);
    }

  }

  public static Session getSessionAndBeginTransaction() {
    Session session = sessionFactory.openSession();
    session.beginTransaction();
    return session;
  }

  public static Session commitCurrentSession(Session session) throws Exception {
    if (session.isOpen()) {
      Transaction transaction = session.getTransaction();
      if (transaction.isActive()) {
        try {
          transaction.commit();
        } catch (Throwable ex) {
          return session;
        }
      }

    }
    return session;
  }

  public static void closeCurrentSessions(Session session) throws Exception {
    if (session != null) {
      if (session.isOpen()) {
        session.close();
      }
    }
  }

}
