package fa.training.utils;

import java.io.IOException;
import java.util.Properties;

public class MessageUtil {
  public static String getMessage(String code) throws IOException{
    Properties properties = new Properties();
    properties.load(MessageUtil.class.getResourceAsStream("/messages.properties"));
    return properties.getProperty(code);
  }
}
