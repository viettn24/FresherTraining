$(document).ready(function () {
	/* Highlight 'a' selected */
	$(".list-group a").click(function () {
		$(".list-group a").removeClass("active");
		$(this).addClass("active");

	});

	/*
	 * Add new a Stock and its detail
	 */
	$("#stockSave").click(function () {		
		var stock_id = $("#theModal #stockId").val();
		var stock_code = $("#theModal #stockCode").val();
		var stock_name = $("#theModal  #stockName").val();
		var company_name = $("#theModal #companyName").val();
		var company_address = $("#theModal #companyAddress").val();
		var remark = $("#theModal #remark").val();
		var listed_date = $("#theModal #listedDate").val();
		
		/*
		 * Create a json object and to submit
		 */
		var stock = new Object();
		stock.stockId = stock_id;
		stock.stockCode = stock_code;
		stock.stockName = stock_name;
		stock.companyName = company_name;
		stock.companyAddress = company_address;
		stock.remark = remark;
		stock.listedDate = listed_date;

		var context_path = $(this).attr("contextPath");
		$.post({
			url:  context_path + "/StockController",
//			dataType: 'json',
			data: JSON.stringify(stock),
			success: function (responeText) {
				$("#saveMessage").html(responeText);
			},
			error: function () {
				window.location = "views/error.jsp";
			}
		});
	});
	
	
	
	$("#bSearch").click(function () {		
		var stock_id = $(".dSearch #stockId").val();
		var stock_code = $(".dSearch #stockCode").val();
		var stock_name = $(".dSearch  #stockName").val();
		var company_name = $(".dSearch #companyName").val();
		var company_address = $(".dSearch #companyAddress").val();
		var remark = $(".dSearch #remark").val();
		var listed_date = $(".dSearch #listedDate").val();
		
		/*
		 * Create a json object and to submit
		 */
		var stock = new Object();
		stock.stockId = stock_id;
		stock.stockCode = stock_code;
		stock.stockName = stock_name;
		stock.companyName = company_name;
		stock.companyAddress = company_address;
		stock.remark = remark;
		stock.listedDate = listed_date;

		var context_path = $(this).attr("contextPath");
		$.post({
			url:  context_path + "/StockActionController",
//			dataType: 'json',
			data: JSON.stringify(stock),
			success: function (responeText) {
				$("#saveMessage").html(responeText);
			},
			error: function () {
				window.location = "views/error.jsp";
			}
		});
	});
	
	

	/*
	 * User select page then submit search form
	 */
	$('select').on('change', function () {
		/*
		 * Add 'page' variable to search form before submit it
		 */
		var input = $("<input>")
			.attr("type", "hidden")
			.attr("name", "page").val(this.value);
		
		$('#fSearch').append(input);

		$("#fSearch").submit();
	});
	
	$(".tStock a").click(function() {
		var stock_id = $(this).attr("value");
		var id = $(this).attr("id");
		
		var context_path = $(this).attr("contextPath");
		if(id.startsWith("update")){
			var stock = new Object();
			stock.stockId = stock_id;
			stock.stockCode = "";
			stock.stockName = "";
			stock.companyName = "";
			stock.companyAddress = "";
			stock.remark = "";
			stock.listedDate = "";
			$.post({
				url: context_path + "/StockActionController",
				dataType: 'json',
				data: JSON.stringify(stock),
				contentType: 'application/json',
		        mimeType: 'application/json',
		        
				success: function (data) {
					$.each(data, function(index, stock){
						$("#theModal #stockId").val(stock.stockId);
						$("#theModal #stockCode").val(stock.stockCode);
						$("#theModal #stockName").val(stock.stockName);
						$("#theModal #companyName").val(stock.companyName);
						$("#theModal #companyAddress").val(stock.companyAddress);
						$("#theModal #remark").val(stock.remark);
						$("#theModal #listedDate").val(stock.listedDate);
						$('#theModal').modal('show');
					});
				},
				
				error: function (data) {
					window.location =  "views/error.jsp";
				}
			});
		}else{
			alert("This module is developmenting!")
		}
	});
	
	
	$("#bClose").click(function() {
		$("#theModal input").val('');
		$("#saveMessage").html('');
	})
})