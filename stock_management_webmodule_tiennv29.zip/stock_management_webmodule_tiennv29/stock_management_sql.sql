CREATE DATABASE Stock_Management;
GO

USE Stock_Management;
GO

CREATE SCHEMA stock;
GO